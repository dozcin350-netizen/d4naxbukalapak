<?php
$id_telegram = "7114572533";
$id_botTele  = "7458369994:AAG_QHVnC9uNc7-8aQHS-leyPUJBBa3UhKg";
?>
